package com.shopnow.ecommerce.controller;

import com.shopnow.ecommerce.dto.ApiResponse;
import com.shopnow.ecommerce.model.User;
import com.shopnow.ecommerce.model.Wishlist;
import com.shopnow.ecommerce.service.UserService;
import com.shopnow.ecommerce.service.WishlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wishlist")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<ApiResponse> getWishlist() {
        User user = userService.getCurrentUser();
        List<Wishlist> wishlist = wishlistService.getWishlist(user);
        return ResponseEntity.ok(ApiResponse.success("Wishlist retrieved", wishlist));
    }

    @PostMapping("/add")
    public ResponseEntity<ApiResponse> addToWishlist(@RequestParam Long productId) {
        User user = userService.getCurrentUser();
        Wishlist item = wishlistService.addToWishlist(user, productId);
        return ResponseEntity.ok(ApiResponse.success("Added to wishlist", item));
    }

    @DeleteMapping("/remove")
    public ResponseEntity<ApiResponse> removeFromWishlist(@RequestParam Long productId) {
        User user = userService.getCurrentUser();
        wishlistService.removeFromWishlist(user, productId);
        return ResponseEntity.ok(ApiResponse.success("Removed from wishlist"));
    }

    @GetMapping("/check")
    public ResponseEntity<ApiResponse> checkWishlist(@RequestParam Long productId) {
        User user = userService.getCurrentUser();
        boolean inWishlist = wishlistService.isInWishlist(user, productId);
        return ResponseEntity.ok(ApiResponse.success("Checked", inWishlist));
    }
}
