package com.shopnow.ecommerce.controller;

import com.shopnow.ecommerce.dto.ApiResponse;
import com.shopnow.ecommerce.model.Cart;
import com.shopnow.ecommerce.model.User;
import com.shopnow.ecommerce.service.CartService;
import com.shopnow.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<ApiResponse> getCart() {
        User user = userService.getCurrentUser();
        Cart cart = cartService.getCartByUser(user);
        BigDecimal total = cartService.getCartTotal(cart);

        Map<String, Object> data = new HashMap<>();
        data.put("cart", cart);
        data.put("total", total);
        data.put("itemCount", cart.getItems().size());

        return ResponseEntity.ok(ApiResponse.success("Cart retrieved", data));
    }

    @PostMapping("/add")
    public ResponseEntity<ApiResponse> addToCart(
            @RequestParam Long productId,
            @RequestParam(defaultValue = "1") Integer quantity) {
        User user = userService.getCurrentUser();
        Cart cart = cartService.addToCart(user, productId, quantity);
        BigDecimal total = cartService.getCartTotal(cart);

        Map<String, Object> data = new HashMap<>();
        data.put("cart", cart);
        data.put("total", total);

        return ResponseEntity.ok(ApiResponse.success("Product added to cart", data));
    }

    @PutMapping("/update")
    public ResponseEntity<ApiResponse> updateCartItem(
            @RequestParam Long productId,
            @RequestParam Integer quantity) {
        User user = userService.getCurrentUser();
        Cart cart = cartService.updateCartItem(user, productId, quantity);
        BigDecimal total = cartService.getCartTotal(cart);

        Map<String, Object> data = new HashMap<>();
        data.put("cart", cart);
        data.put("total", total);

        return ResponseEntity.ok(ApiResponse.success("Cart updated", data));
    }

    @DeleteMapping("/remove")
    public ResponseEntity<ApiResponse> removeFromCart(@RequestParam Long productId) {
        User user = userService.getCurrentUser();
        Cart cart = cartService.removeFromCart(user, productId);
        BigDecimal total = cartService.getCartTotal(cart);

        Map<String, Object> data = new HashMap<>();
        data.put("cart", cart);
        data.put("total", total);

        return ResponseEntity.ok(ApiResponse.success("Product removed from cart", data));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<ApiResponse> clearCart() {
        User user = userService.getCurrentUser();
        cartService.clearCart(user);
        return ResponseEntity.ok(ApiResponse.success("Cart cleared"));
    }
}
