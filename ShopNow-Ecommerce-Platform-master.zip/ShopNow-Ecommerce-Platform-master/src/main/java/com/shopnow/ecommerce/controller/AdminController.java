package com.shopnow.ecommerce.controller;

import com.shopnow.ecommerce.dto.ApiResponse;
import com.shopnow.ecommerce.dto.DashboardStats;
import com.shopnow.ecommerce.model.*;
import com.shopnow.ecommerce.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @Autowired
    private CouponService couponService;

    // ========== Dashboard ==========
    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse> getDashboard() {
        DashboardStats stats = orderService.getDashboardStats();
        return ResponseEntity.ok(ApiResponse.success("Dashboard stats", stats));
    }

    // ========== Products ==========
    @PostMapping("/products")
    public ResponseEntity<ApiResponse> createProduct(
            @RequestParam String name,
            @RequestParam(required = false) String description,
            @RequestParam Double price,
            @RequestParam Integer stock,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) MultipartFile image) {

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(java.math.BigDecimal.valueOf(price));
        product.setStock(stock);

        if (image != null && !image.isEmpty()) {
            String imageUrl = productService.uploadImage(image);
            product.setImageUrl(imageUrl);
        }

        Product created = productService.createProduct(product, categoryId);
        return ResponseEntity.ok(ApiResponse.success("Product created", created));
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<ApiResponse> updateProduct(
            @PathVariable Long id,
            @RequestParam String name,
            @RequestParam(required = false) String description,
            @RequestParam Double price,
            @RequestParam Integer stock,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) MultipartFile image) {

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(java.math.BigDecimal.valueOf(price));
        product.setStock(stock);

        if (image != null && !image.isEmpty()) {
            String imageUrl = productService.uploadImage(image);
            product.setImageUrl(imageUrl);
        }

        Product updated = productService.updateProduct(id, product, categoryId);
        return ResponseEntity.ok(ApiResponse.success("Product updated", updated));
    }

    @DeleteMapping("/products/{id}")
    public ResponseEntity<ApiResponse> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.ok(ApiResponse.success("Product deleted"));
    }

    @PutMapping("/products/{id}/stock")
    public ResponseEntity<ApiResponse> updateStock(@PathVariable Long id, @RequestParam int stock) {
        Product product = productService.updateStock(id, stock);
        return ResponseEntity.ok(ApiResponse.success("Stock updated", product));
    }

    @GetMapping("/products/low-stock")
    public ResponseEntity<ApiResponse> getLowStockProducts(
            @RequestParam(defaultValue = "10") int threshold) {
        List<Product> products = productService.getLowStockProducts(threshold);
        return ResponseEntity.ok(ApiResponse.success("Low stock products", products));
    }

    @PostMapping("/products/upload-image")
    public ResponseEntity<ApiResponse> uploadImage(@RequestParam MultipartFile file) {
        String url = productService.uploadImage(file);
        return ResponseEntity.ok(ApiResponse.success("Image uploaded", url));
    }

    // ========== Categories ==========
    @PostMapping("/categories")
    public ResponseEntity<ApiResponse> createCategory(@Valid @RequestBody Category category) {
        return ResponseEntity.ok(ApiResponse.success("Category created", categoryService.createCategory(category)));
    }

    @PutMapping("/categories/{id}")
    public ResponseEntity<ApiResponse> updateCategory(@PathVariable Long id, @Valid @RequestBody Category category) {
        return ResponseEntity.ok(ApiResponse.success("Category updated", categoryService.updateCategory(id, category)));
    }

    @DeleteMapping("/categories/{id}")
    public ResponseEntity<ApiResponse> deleteCategory(@PathVariable Long id) {
        categoryService.deleteCategory(id);
        return ResponseEntity.ok(ApiResponse.success("Category deleted"));
    }

    // ========== Orders ==========
    @GetMapping("/orders")
    public ResponseEntity<ApiResponse> getAllOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<Order> orders = orderService.getAllOrders(page, size);
        return ResponseEntity.ok(ApiResponse.success("All orders", orders));
    }

    @PutMapping("/orders/{id}/status")
    public ResponseEntity<ApiResponse> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        Order order = orderService.updateOrderStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Order status updated", order));
    }

    // ========== Users ==========
    @GetMapping("/users")
    public ResponseEntity<ApiResponse> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.success("All users", userService.getAllUsers()));
    }

    @GetMapping("/users/customers")
    public ResponseEntity<ApiResponse> getCustomers() {
        return ResponseEntity.ok(ApiResponse.success("Customers", userService.getCustomers()));
    }

    @PutMapping("/users/{id}/toggle-status")
    public ResponseEntity<ApiResponse> toggleUserStatus(@PathVariable Long id) {
        User user = userService.toggleUserStatus(id);
        return ResponseEntity.ok(ApiResponse.success("User status updated", user));
    }

    // ========== Coupons ==========
    @GetMapping("/coupons")
    public ResponseEntity<ApiResponse> getAllCoupons() {
        return ResponseEntity.ok(ApiResponse.success("All coupons", couponService.getAllCoupons()));
    }

    @PostMapping("/coupons")
    public ResponseEntity<ApiResponse> createCoupon(@Valid @RequestBody Coupon coupon) {
        return ResponseEntity.ok(ApiResponse.success("Coupon created", couponService.createCoupon(coupon)));
    }

    @PutMapping("/coupons/{id}")
    public ResponseEntity<ApiResponse> updateCoupon(@PathVariable Long id, @Valid @RequestBody Coupon coupon) {
        return ResponseEntity.ok(ApiResponse.success("Coupon updated", couponService.updateCoupon(id, coupon)));
    }

    @DeleteMapping("/coupons/{id}")
    public ResponseEntity<ApiResponse> deleteCoupon(@PathVariable Long id) {
        couponService.deleteCoupon(id);
        return ResponseEntity.ok(ApiResponse.success("Coupon deleted"));
    }
}
