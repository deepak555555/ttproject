package com.shopnow.ecommerce.service;

import com.shopnow.ecommerce.exception.ResourceNotFoundException;
import com.shopnow.ecommerce.model.Product;
import com.shopnow.ecommerce.model.User;
import com.shopnow.ecommerce.model.Wishlist;
import com.shopnow.ecommerce.repository.ProductRepository;
import com.shopnow.ecommerce.repository.WishlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private ProductRepository productRepository;

    public List<Wishlist> getWishlist(User user) {
        return wishlistRepository.findByUserId(user.getId());
    }

    @Transactional
    public Wishlist addToWishlist(User user, Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        if (wishlistRepository.existsByUserIdAndProductId(user.getId(), productId)) {
            return wishlistRepository.findByUserIdAndProductId(user.getId(), productId).get();
        }

        Wishlist wishlist = new Wishlist(user, product);
        return wishlistRepository.save(wishlist);
    }

    @Transactional
    public void removeFromWishlist(User user, Long productId) {
        Wishlist wishlist = wishlistRepository.findByUserIdAndProductId(user.getId(), productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found in wishlist"));
        wishlistRepository.delete(wishlist);
    }

    public boolean isInWishlist(User user, Long productId) {
        return wishlistRepository.existsByUserIdAndProductId(user.getId(), productId);
    }
}
