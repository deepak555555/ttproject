package com.shopnow.ecommerce.service;

import com.shopnow.ecommerce.dto.CheckoutRequest;
import com.shopnow.ecommerce.dto.DashboardStats;
import com.shopnow.ecommerce.exception.BadRequestException;
import com.shopnow.ecommerce.exception.InsufficientStockException;
import com.shopnow.ecommerce.exception.ResourceNotFoundException;
import com.shopnow.ecommerce.model.*;
import com.shopnow.ecommerce.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private CouponService couponService;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public Order placeOrder(User user, CheckoutRequest request) {
        Cart cart = cartService.getCartByUser(user);

        if (cart.getItems().isEmpty()) {
            throw new BadRequestException("Cart is empty");
        }

        // Validate stock & calculate total
        BigDecimal subtotal = BigDecimal.ZERO;
        for (CartItem cartItem : cart.getItems()) {
            Product product = cartItem.getProduct();
            if (!product.getActive()) {
                throw new BadRequestException("Product '" + product.getName() + "' is no longer available");
            }
            if (product.getStock() < cartItem.getQuantity()) {
                throw new InsufficientStockException(
                        "Insufficient stock for '" + product.getName() + "'. Available: " + product.getStock());
            }
            subtotal = subtotal.add(product.getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity())));
        }

        // Apply coupon
        BigDecimal discount = BigDecimal.ZERO;
        Coupon coupon = null;
        if (request.getCouponCode() != null && !request.getCouponCode().isEmpty()) {
            coupon = couponService.validateCoupon(request.getCouponCode(), subtotal);
            discount = couponService.calculateDiscount(coupon, subtotal);
        }

        BigDecimal totalPrice = subtotal.subtract(discount);

        // Create order
        Order order = new Order();
        order.setUser(user);
        order.setTotalPrice(totalPrice);
        order.setDiscountAmount(discount);
        order.setCouponCode(request.getCouponCode());
        order.setShippingAddress(request.getShippingAddress() != null ?
                request.getShippingAddress() : user.getAddress());
        order.setStatus(Order.OrderStatus.PENDING);

        order = orderRepository.save(order);

        // Create order items & update stock
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cart.getItems()) {
            Product product = cartItem.getProduct();

            OrderItem orderItem = new OrderItem(order, product, cartItem.getQuantity(), product.getPrice());
            orderItems.add(orderItem);

            // Decrease stock
            product.setStock(product.getStock() - cartItem.getQuantity());
            productRepository.save(product);
        }
        order.setItems(orderItems);
        order = orderRepository.save(order);

        // Create payment
        Payment.PaymentMethod paymentMethod = Payment.PaymentMethod.COD;
        if (request.getPaymentMethod() != null) {
            try {
                paymentMethod = Payment.PaymentMethod.valueOf(request.getPaymentMethod().toUpperCase());
            } catch (IllegalArgumentException e) {
                paymentMethod = Payment.PaymentMethod.COD;
            }
        }

        Payment payment = new Payment(order, totalPrice, paymentMethod);
        if (paymentMethod != Payment.PaymentMethod.COD) {
            payment.setPaymentStatus(Payment.PaymentStatus.SUCCESS);
            payment.setTransactionId("TXN" + UUID.randomUUID().toString().substring(0, 12).toUpperCase());
            order.setStatus(Order.OrderStatus.CONFIRMED);
            orderRepository.save(order);
        }
        paymentRepository.save(payment);

        // Increment coupon usage
        if (coupon != null) {
            couponService.incrementUsage(coupon);
        }

        // Clear cart
        cartService.clearCart(user);

        logger.info("Order placed successfully. Order ID: {}, User: {}", order.getId(), user.getEmail());

        return order;
    }

    public List<Order> getUserOrders(User user) {
        return orderRepository.findByUserOrderByCreatedAtDesc(user);
    }

    public Page<Order> getUserOrdersPaged(User user, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return orderRepository.findByUserOrderByCreatedAtDesc(user, pageable);
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
    }

    public Order getOrderForUser(User user, Long orderId) {
        Order order = getOrderById(orderId);
        if (!order.getUser().getId().equals(user.getId())) {
            throw new ResourceNotFoundException("Order not found");
        }
        return order;
    }

    @Transactional
    public Order cancelOrder(User user, Long orderId) {
        Order order = getOrderForUser(user, orderId);

        if (order.getStatus() == Order.OrderStatus.SHIPPED ||
            order.getStatus() == Order.OrderStatus.DELIVERED) {
            throw new BadRequestException("Cannot cancel order that is already " + order.getStatus());
        }

        if (order.getStatus() == Order.OrderStatus.CANCELLED) {
            throw new BadRequestException("Order is already cancelled");
        }

        // Restore stock
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.setStock(product.getStock() + item.getQuantity());
            productRepository.save(product);
        }

        order.setStatus(Order.OrderStatus.CANCELLED);

        // Update payment
        Payment payment = paymentRepository.findByOrderId(orderId).orElse(null);
        if (payment != null) {
            payment.setPaymentStatus(Payment.PaymentStatus.REFUNDED);
            paymentRepository.save(payment);
        }

        logger.info("Order cancelled. Order ID: {}", orderId);
        return orderRepository.save(order);
    }

    // Admin methods
    public Page<Order> getAllOrders(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return orderRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    @Transactional
    public Order updateOrderStatus(Long orderId, String status) {
        Order order = getOrderById(orderId);
        try {
            Order.OrderStatus newStatus = Order.OrderStatus.valueOf(status.toUpperCase());
            order.setStatus(newStatus);

            // If delivered, update payment status
            if (newStatus == Order.OrderStatus.DELIVERED) {
                Payment payment = paymentRepository.findByOrderId(orderId).orElse(null);
                if (payment != null && payment.getMethod() == Payment.PaymentMethod.COD) {
                    payment.setPaymentStatus(Payment.PaymentStatus.SUCCESS);
                    payment.setTransactionId("COD" + UUID.randomUUID().toString().substring(0, 12).toUpperCase());
                    paymentRepository.save(payment);
                }
            }

            return orderRepository.save(order);
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid order status: " + status);
        }
    }

    public DashboardStats getDashboardStats() {
        DashboardStats stats = new DashboardStats();

        stats.setTotalProducts(productRepository.countByActiveTrue());
        stats.setTotalOrders(orderRepository.count());
        stats.setTotalCustomers(userRepository.countByRole(User.Role.CUSTOMER));

        BigDecimal totalRevenue = orderRepository.getTotalRevenue();
        stats.setTotalRevenue(totalRevenue != null ? totalRevenue : BigDecimal.ZERO);

        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
        BigDecimal todayRevenue = orderRepository.getRevenueSince(today);
        stats.setTodayRevenue(todayRevenue != null ? todayRevenue : BigDecimal.ZERO);

        LocalDateTime monthStart = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        BigDecimal monthRevenue = orderRepository.getRevenueSince(monthStart);
        stats.setMonthRevenue(monthRevenue != null ? monthRevenue : BigDecimal.ZERO);

        stats.setPendingOrders(orderRepository.countByStatus(Order.OrderStatus.PENDING));
        stats.setLowStockProducts(productRepository.findByStockLessThan(10).size());

        // Order counts by status
        Map<String, Long> statusCounts = new LinkedHashMap<>();
        List<Object[]> statusData = orderRepository.getOrderCountByStatus();
        for (Object[] row : statusData) {
            statusCounts.put(row[0].toString(), (Long) row[1]);
        }
        stats.setOrdersByStatus(statusCounts);

        // Daily revenue for last 30 days
        LocalDateTime thirtyDaysAgo = LocalDateTime.now().minusDays(30);
        stats.setDailyRevenue(orderRepository.getDailyRevenue(thirtyDaysAgo));

        return stats;
    }
}
