package com.shopnow.ecommerce.config;

import com.shopnow.ecommerce.model.*;
import com.shopnow.ecommerce.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(UserRepository userRepo, CategoryRepository catRepo,
                                ProductRepository productRepo, CouponRepository couponRepo,
                                CartRepository cartRepo, PasswordEncoder passwordEncoder) {
        return args -> {
            // Only init if database is empty
            if (userRepo.count() > 0) return;

            System.out.println("=== Initializing sample data ===");

            // Admin user
            User admin = new User();
            admin.setName("Admin User");
            admin.setEmail("admin@shopnow.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setPhone("9999999999");
            admin.setAddress("ShopNow HQ, Mumbai");
            admin.setRole(User.Role.ADMIN);
            admin.setStatus(User.UserStatus.ACTIVE);
            userRepo.save(admin);

            // Demo customer
            User customer = new User();
            customer.setName("John Doe");
            customer.setEmail("john@example.com");
            customer.setPassword(passwordEncoder.encode("customer123"));
            customer.setPhone("9876543210");
            customer.setAddress("123 Main Street, New Delhi");
            customer.setRole(User.Role.CUSTOMER);
            customer.setStatus(User.UserStatus.ACTIVE);
            userRepo.save(customer);

            // Cart for customer
            Cart cart = new Cart();
            cart.setUser(customer);
            cartRepo.save(cart);

            // Categories
            Category electronics = createCat(catRepo, "Electronics", "Smartphones, laptops, accessories and more", "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400");
            Category fashion = createCat(catRepo, "Fashion", "Clothing, shoes, and fashion accessories", "https://images.unsplash.com/photo-1445205170230-053b83016050?w=400");
            Category home = createCat(catRepo, "Home & Kitchen", "Furniture, appliances, and home decor", "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400");
            Category books = createCat(catRepo, "Books", "Fiction, non-fiction, educational and more", "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400");
            Category sports = createCat(catRepo, "Sports & Fitness", "Gym equipment, sportswear, and accessories", "https://images.unsplash.com/photo-1461896836934-bd45ba4c4d32?w=400");
            Category beauty = createCat(catRepo, "Beauty & Health", "Skincare, makeup, and wellness products", "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400");

            // Products - Electronics
            createProduct(productRepo, "iPhone 15 Pro Max", "Apple iPhone 15 Pro Max with A17 Pro chip, 48MP camera system, titanium design, and USB-C connectivity. 256GB storage.", 134900, 25, "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400", electronics);
            createProduct(productRepo, "Samsung Galaxy S24 Ultra", "Samsung Galaxy S24 Ultra with Snapdragon 8 Gen 3, 200MP camera, S Pen, and AI features. 512GB storage.", 129999, 30, "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400", electronics);
            createProduct(productRepo, "MacBook Air M3", "Apple MacBook Air with M3 chip, 15.3-inch Liquid Retina display, 16GB RAM, 512GB SSD.", 149900, 15, "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400", electronics);
            createProduct(productRepo, "Sony WH-1000XM5", "Industry-leading noise canceling headphones with exceptional sound quality and 30-hour battery life.", 29990, 50, "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400", electronics);
            createProduct(productRepo, "iPad Pro 12.9\"", "Apple iPad Pro with M2 chip, 12.9-inch Liquid Retina XDR display, Wi-Fi 6E, Face ID.", 112900, 20, "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400", electronics);

            // Products - Fashion
            createProduct(productRepo, "Premium Cotton Shirt", "Handcrafted premium cotton formal shirt with French cuffs. Available in multiple colors.", 2499, 100, "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400", fashion);
            createProduct(productRepo, "Leather Jacket", "Genuine leather biker jacket with quilted lining. Water-resistant finish with premium YKK zippers.", 8999, 35, "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400", fashion);
            createProduct(productRepo, "Running Sneakers Pro", "Ultra-lightweight running shoes with responsive cushioning and breathable mesh upper.", 6999, 60, "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400", fashion);

            // Products - Home & Kitchen
            createProduct(productRepo, "Instant Pot Duo Plus", "Multi-functional pressure cooker - 9-in-1 with advanced safety features. 6-quart capacity.", 8499, 40, "https://images.unsplash.com/photo-1585515320310-259814833e62?w=400", home);
            createProduct(productRepo, "Ergonomic Office Chair", "Premium ergonomic mesh office chair with lumbar support, adjustable armrests.", 15999, 20, "https://images.unsplash.com/photo-1592078615290-033ee584e267?w=400", home);
            createProduct(productRepo, "Smart LED Lamp", "WiFi-enabled smart LED desk lamp with adjustable color temperature and touch controls.", 3499, 75, "https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=400", home);

            // Products - Books
            createProduct(productRepo, "Clean Code by Robert Martin", "A handbook of agile software craftsmanship. Essential reading for every professional developer.", 599, 200, "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400", books);
            createProduct(productRepo, "Atomic Habits by James Clear", "Tiny changes, remarkable results. An easy & proven way to build good habits.", 499, 150, "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400", books);

            // Products - Sports & Fitness
            createProduct(productRepo, "Yoga Mat Premium", "Extra thick (6mm) eco-friendly yoga mat with alignment lines and non-slip surface.", 1999, 80, "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400", sports);
            createProduct(productRepo, "Adjustable Dumbbell Set", "Space-saving adjustable dumbbells 5-25kg with quick-change mechanism.", 12999, 25, "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400", sports);
            createProduct(productRepo, "Smart Fitness Watch", "Advanced fitness tracker with GPS, heart rate monitor, SpO2, and 14-day battery.", 4999, 5, "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=400", sports);

            // Products - Beauty & Health
            createProduct(productRepo, "Vitamin C Serum", "Professional-grade 20% Vitamin C serum with hyaluronic acid. Brightens skin.", 1299, 120, "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400", beauty);
            createProduct(productRepo, "Essential Oil Diffuser", "Ultrasonic aromatherapy diffuser with 7 LED color modes, timer settings. 300ml.", 2499, 55, "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400", beauty);

            // Coupons
            createCoupon(couponRepo, "WELCOME10", 10, 500, 1000, "2027-12-31", 1000);
            createCoupon(couponRepo, "FLAT20", 20, 2000, 5000, "2027-06-30", 500);
            createCoupon(couponRepo, "MEGA50", 50, 10000, 25000, "2027-03-31", 100);

            System.out.println("=== Sample data initialized successfully! ===");
            System.out.println("Admin: admin@shopnow.com / admin123");
            System.out.println("Customer: john@example.com / customer123");
        };
    }

    private Category createCat(CategoryRepository repo, String name, String desc, String img) {
        Category c = new Category();
        c.setName(name);
        c.setDescription(desc);
        c.setImageUrl(img);
        return repo.save(c);
    }

    private void createProduct(ProductRepository repo, String name, String desc, double price, int stock, String img, Category cat) {
        Product p = new Product();
        p.setName(name);
        p.setDescription(desc);
        p.setPrice(BigDecimal.valueOf(price));
        p.setStock(stock);
        p.setImageUrl(img);
        p.setCategory(cat);
        p.setActive(true);
        repo.save(p);
    }

    private void createCoupon(CouponRepository repo, String code, double discount, double minOrder, double maxDiscount, String expiry, int limit) {
        Coupon c = new Coupon();
        c.setCode(code);
        c.setDiscount(BigDecimal.valueOf(discount));
        c.setMinOrderAmount(BigDecimal.valueOf(minOrder));
        c.setMaxDiscountAmount(BigDecimal.valueOf(maxDiscount));
        c.setExpiryDate(LocalDate.parse(expiry));
        c.setActive(true);
        c.setUsageLimit(limit);
        c.setTimesUsed(0);
        repo.save(c);
    }
}
