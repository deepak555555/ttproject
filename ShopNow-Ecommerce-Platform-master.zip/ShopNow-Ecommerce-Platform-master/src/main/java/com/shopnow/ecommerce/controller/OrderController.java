package com.shopnow.ecommerce.controller;

import com.shopnow.ecommerce.dto.ApiResponse;
import com.shopnow.ecommerce.dto.CheckoutRequest;
import com.shopnow.ecommerce.model.Order;
import com.shopnow.ecommerce.model.User;
import com.shopnow.ecommerce.service.CouponService;
import com.shopnow.ecommerce.service.OrderService;
import com.shopnow.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @Autowired
    private CouponService couponService;

    @PostMapping("/checkout")
    public ResponseEntity<ApiResponse> checkout(@RequestBody CheckoutRequest request) {
        User user = userService.getCurrentUser();
        Order order = orderService.placeOrder(user, request);
        return ResponseEntity.ok(ApiResponse.success("Order placed successfully", order));
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getMyOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        User user = userService.getCurrentUser();
        Page<Order> orders = orderService.getUserOrdersPaged(user, page, size);
        return ResponseEntity.ok(ApiResponse.success("Orders retrieved", orders));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getOrderById(@PathVariable Long id) {
        User user = userService.getCurrentUser();
        Order order = orderService.getOrderForUser(user, id);
        return ResponseEntity.ok(ApiResponse.success("Order retrieved", order));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse> cancelOrder(@PathVariable Long id) {
        User user = userService.getCurrentUser();
        Order order = orderService.cancelOrder(user, id);
        return ResponseEntity.ok(ApiResponse.success("Order cancelled successfully", order));
    }

    @PostMapping("/validate-coupon")
    public ResponseEntity<ApiResponse> validateCoupon(
            @RequestParam String code,
            @RequestParam BigDecimal orderTotal) {
        var coupon = couponService.validateCoupon(code, orderTotal);
        BigDecimal discount = couponService.calculateDiscount(coupon, orderTotal);

        Map<String, Object> data = new HashMap<>();
        data.put("coupon", coupon);
        data.put("discount", discount);
        data.put("finalTotal", orderTotal.subtract(discount));

        return ResponseEntity.ok(ApiResponse.success("Coupon applied successfully", data));
    }
}
