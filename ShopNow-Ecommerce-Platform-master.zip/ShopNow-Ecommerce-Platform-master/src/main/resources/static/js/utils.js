// ============================================
// ShopNow E-Commerce - Utilities
// ============================================

function formatPrice(price) {
    return '₹' + Number(price).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatDateTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function showLoading() {
    document.getElementById('loading-overlay').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loading-overlay').classList.add('hidden');
}

function getStockLabel(stock) {
    if (stock === 0) return '<span class="product-stock stock-out">Out of Stock</span>';
    if (stock <= 10) return `<span class="product-stock stock-low">Only ${stock} left</span>`;
    return '<span class="product-stock stock-in">In Stock</span>';
}

function getStockClass(stock) {
    if (stock === 0) return 'stock-out';
    if (stock <= 10) return 'stock-low';
    return 'stock-in';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function createPagination(page, totalPages, onPageChange) {
    if (totalPages <= 1) return '';

    let html = '<div class="pagination">';
    html += `<button class="page-btn" ${page === 0 ? 'disabled' : ''} onclick="${onPageChange}(${page - 1})"><i class="fas fa-chevron-left"></i></button>`;

    const start = Math.max(0, page - 2);
    const end = Math.min(totalPages - 1, page + 2);

    if (start > 0) {
        html += `<button class="page-btn" onclick="${onPageChange}(0)">1</button>`;
        if (start > 1) html += '<span style="color:var(--text-muted);padding:0.5rem">...</span>';
    }

    for (let i = start; i <= end; i++) {
        html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="${onPageChange}(${i})">${i + 1}</button>`;
    }

    if (end < totalPages - 1) {
        if (end < totalPages - 2) html += '<span style="color:var(--text-muted);padding:0.5rem">...</span>';
        html += `<button class="page-btn" onclick="${onPageChange}(${totalPages - 1})">${totalPages}</button>`;
    }

    html += `<button class="page-btn" ${page === totalPages - 1 ? 'disabled' : ''} onclick="${onPageChange}(${page + 1})"><i class="fas fa-chevron-right"></i></button>`;
    html += '</div>';
    return html;
}

function getProductImageUrl(product) {
    if (product.imageUrl) return product.imageUrl;
    return `https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400`;
}

function closeModal() {
    const overlay = document.querySelector('.modal-overlay');
    if (overlay) overlay.remove();
}

function showModal(title, bodyHtml, footerHtml = '') {
    closeModal();
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.onclick = (e) => { if (e.target === modal) closeModal(); };
    modal.innerHTML = `
        <div class="modal">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">${bodyHtml}</div>
            ${footerHtml ? `<div class="modal-footer">${footerHtml}</div>` : ''}
        </div>
    `;
    document.body.appendChild(modal);
}
