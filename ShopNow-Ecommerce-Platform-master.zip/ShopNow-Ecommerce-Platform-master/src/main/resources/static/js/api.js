// ============================================
// ShopNow E-Commerce - API Layer
// ============================================

const API_BASE = '/api';

class ApiClient {
    constructor() {
        this.token = localStorage.getItem('shopnow_token');
    }

    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('shopnow_token', token);
        } else {
            localStorage.removeItem('shopnow_token');
        }
    }

    getHeaders(isFormData = false) {
        const headers = {};
        if (!isFormData) {
            headers['Content-Type'] = 'application/json';
        }
        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }
        return headers;
    }

    async request(method, endpoint, data = null, isFormData = false) {
        const config = {
            method,
            headers: this.getHeaders(isFormData),
        };

        if (data) {
            config.body = isFormData ? data : JSON.stringify(data);
        }

        try {
            const response = await fetch(`${API_BASE}${endpoint}`, config);

            if (response.status === 401) {
                this.setToken(null);
                localStorage.removeItem('shopnow_user');
                if (window.location.hash !== '#login') {
                    showToast('Session expired. Please login again.', 'warning');
                    navigate('login');
                }
                throw new Error('Unauthorized');
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const result = await response.json();
                if (!response.ok) {
                    throw new Error(result.message || 'Something went wrong');
                }
                return result;
            }

            if (!response.ok) {
                throw new Error('Something went wrong');
            }

            return await response.text();
        } catch (error) {
            if (error.message !== 'Unauthorized') {
                console.error(`API Error [${method} ${endpoint}]:`, error);
            }
            throw error;
        }
    }

    get(endpoint) { return this.request('GET', endpoint); }
    post(endpoint, data) { return this.request('POST', endpoint, data); }
    put(endpoint, data) { return this.request('PUT', endpoint, data); }
    delete(endpoint) { return this.request('DELETE', endpoint); }
    postForm(endpoint, formData) { return this.request('POST', endpoint, formData, true); }
    putForm(endpoint, formData) { return this.request('PUT', endpoint, formData, true); }

    // Auth
    login(email, password) { return this.post('/auth/login', { email, password }); }
    register(data) { return this.post('/auth/register', data); }
    getMe() { return this.get('/auth/me'); }
    updateProfile(data) { return this.put('/auth/profile', data); }

    // Products
    getProducts(page = 0, size = 12, sortBy = 'createdAt', direction = 'desc') {
        return this.get(`/products?page=${page}&size=${size}&sortBy=${sortBy}&direction=${direction}`);
    }
    getProduct(id) { return this.get(`/products/${id}`); }
    searchProducts(query, page = 0, size = 12) {
        return this.get(`/products/search?query=${encodeURIComponent(query)}&page=${page}&size=${size}`);
    }
    filterProducts(params) {
        const qs = new URLSearchParams(params).toString();
        return this.get(`/products/filter?${qs}`);
    }
    getRecommendations(id) { return this.get(`/products/${id}/recommendations`); }
    getSuggestions(query) { return this.get(`/products/suggestions?query=${encodeURIComponent(query)}`); }
    getProductsByCategory(catId, page = 0) { return this.get(`/products/category/${catId}?page=${page}`); }

    // Categories
    getCategories() { return this.get('/categories'); }

    // Cart
    getCart() { return this.get('/cart'); }
    addToCart(productId, quantity = 1) { return this.post(`/cart/add?productId=${productId}&quantity=${quantity}`); }
    updateCartItem(productId, quantity) { return this.put(`/cart/update?productId=${productId}&quantity=${quantity}`); }
    removeFromCart(productId) { return this.delete(`/cart/remove?productId=${productId}`); }
    clearCart() { return this.delete('/cart/clear'); }

    // Wishlist
    getWishlist() { return this.get('/wishlist'); }
    addToWishlist(productId) { return this.post(`/wishlist/add?productId=${productId}`); }
    removeFromWishlist(productId) { return this.delete(`/wishlist/remove?productId=${productId}`); }
    checkWishlist(productId) { return this.get(`/wishlist/check?productId=${productId}`); }

    // Orders
    checkout(data) { return this.post('/orders/checkout', data); }
    getOrders(page = 0, size = 10) { return this.get(`/orders?page=${page}&size=${size}`); }
    getOrder(id) { return this.get(`/orders/${id}`); }
    cancelOrder(id) { return this.post(`/orders/${id}/cancel`); }
    validateCoupon(code, total) { return this.post(`/orders/validate-coupon?code=${encodeURIComponent(code)}&orderTotal=${total}`); }

    // Admin
    getDashboard() { return this.get('/admin/dashboard'); }
    createProduct(formData) { return this.postForm('/admin/products', formData); }
    updateProduct(id, formData) { return this.putForm(`/admin/products/${id}`, formData); }
    deleteProduct(id) { return this.delete(`/admin/products/${id}`); }
    updateStock(id, stock) { return this.put(`/admin/products/${id}/stock?stock=${stock}`); }
    getLowStock(threshold = 10) { return this.get(`/admin/products/low-stock?threshold=${threshold}`); }
    uploadImage(formData) { return this.postForm('/admin/products/upload-image', formData); }

    createCategory(data) { return this.post('/admin/categories', data); }
    updateCategory(id, data) { return this.put(`/admin/categories/${id}`, data); }
    deleteCategory(id) { return this.delete(`/admin/categories/${id}`); }

    getAllOrders(page = 0, size = 10) { return this.get(`/admin/orders?page=${page}&size=${size}`); }
    updateOrderStatus(id, status) { return this.put(`/admin/orders/${id}/status?status=${status}`); }

    getAllUsers() { return this.get('/admin/users'); }
    getCustomers() { return this.get('/admin/users/customers'); }
    toggleUserStatus(id) { return this.put(`/admin/users/${id}/toggle-status`); }

    getCoupons() { return this.get('/admin/coupons'); }
    createCoupon(data) { return this.post('/admin/coupons', data); }
    updateCoupon(id, data) { return this.put(`/admin/coupons/${id}`, data); }
    deleteCoupon(id) { return this.delete(`/admin/coupons/${id}`); }
}

const api = new ApiClient();
