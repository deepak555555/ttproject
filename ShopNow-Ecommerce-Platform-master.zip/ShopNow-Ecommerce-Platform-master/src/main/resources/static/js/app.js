// ============================================
// ShopNow E-Commerce - Main App Controller
// ============================================

// ========== STATE ==========
function isLoggedIn() {
    return !!localStorage.getItem('shopnow_token') && !!localStorage.getItem('shopnow_user');
}

function getCurrentUser() {
    try {
        return JSON.parse(localStorage.getItem('shopnow_user'));
    } catch { return null; }
}

function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'ADMIN';
}

// ========== NAVIGATION ==========
function navigate(page, param) {
    window.scrollTo(0, 0);
    closeModal();

    switch (page) {
        case 'home': renderHomePage(); break;
        case 'login':
            if (isLoggedIn()) { navigate('home'); return; }
            renderLoginPage(); break;
        case 'register':
            if (isLoggedIn()) { navigate('home'); return; }
            renderRegisterPage(); break;
        case 'product': renderProductDetail(param); break;
        case 'cart':
            if (!isLoggedIn()) { showToast('Please login first', 'warning'); navigate('login'); return; }
            renderCartPage(); break;
        case 'checkout':
            if (!isLoggedIn()) { navigate('login'); return; }
            renderCheckoutPage(); break;
        case 'orders':
            if (!isLoggedIn()) { navigate('login'); return; }
            renderOrdersPage(); break;
        case 'wishlist':
            if (!isLoggedIn()) { navigate('login'); return; }
            renderWishlistPage(); break;
        case 'profile':
            if (!isLoggedIn()) { navigate('login'); return; }
            renderProfilePage(); break;
        case 'admin':
            if (!isAdmin()) { showToast('Access denied', 'error'); navigate('home'); return; }
            renderAdminPage(); break;
        default: renderHomePage();
    }
}

// ========== NAVBAR ==========
function updateNavBar() {
    const guestNav = document.getElementById('nav-guest');
    const userNav = document.getElementById('nav-user');
    const adminLink = document.getElementById('admin-link');

    if (isLoggedIn()) {
        const user = getCurrentUser();
        guestNav.classList.add('hidden');
        userNav.classList.remove('hidden');
        document.getElementById('user-name-display').textContent = user.name;
        document.getElementById('user-email-display').textContent = user.email;

        if (user.role === 'ADMIN') {
            adminLink.classList.remove('hidden');
        } else {
            adminLink.classList.add('hidden');
        }

        updateCartBadge();
    } else {
        guestNav.classList.remove('hidden');
        userNav.classList.add('hidden');
    }
}

async function updateCartBadge() {
    if (!isLoggedIn()) return;
    try {
        const result = await api.getCart();
        const count = result.data?.itemCount || 0;
        const badge = document.getElementById('cart-badge');
        if (badge) {
            badge.textContent = count;
            badge.classList.toggle('hidden', count === 0);
        }
    } catch (e) { /* ignore */ }
}

function logout() {
    api.setToken(null);
    localStorage.removeItem('shopnow_user');
    showToast('Logged out successfully', 'info');
    updateNavBar();
    navigate('home');
}

// ========== SEARCH ==========
const searchInput = document.getElementById('search-input');
const suggestionsDiv = document.getElementById('search-suggestions');

if (searchInput) {
    searchInput.addEventListener('input', debounce(async function() {
        const query = this.value.trim();
        if (query.length < 2) {
            suggestionsDiv.classList.add('hidden');
            return;
        }

        try {
            const suggestions = await api.getSuggestions(query);
            if (suggestions.length > 0) {
                suggestionsDiv.innerHTML = suggestions.map(s =>
                    `<div class="suggestion-item" onclick="searchFromSuggestion('${escapeHtml(s)}')">${escapeHtml(s)}</div>`
                ).join('');
                suggestionsDiv.classList.remove('hidden');
            } else {
                suggestionsDiv.classList.add('hidden');
            }
        } catch (e) {
            suggestionsDiv.classList.add('hidden');
        }
    }, 300));

    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const query = this.value.trim();
            if (query) {
                currentSearch = query;
                currentCategory = null;
                suggestionsDiv.classList.add('hidden');
                navigate('home');
                setTimeout(() => loadProducts(0), 100);
            }
        }
    });

    // Close suggestions when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.search-wrapper')) {
            suggestionsDiv.classList.add('hidden');
        }
    });
}

function searchFromSuggestion(query) {
    searchInput.value = query;
    currentSearch = query;
    currentCategory = null;
    suggestionsDiv.classList.add('hidden');
    navigate('home');
    setTimeout(() => loadProducts(0), 100);
}

// ========== USER MENU DROPDOWN ==========
const userMenuBtn = document.getElementById('user-menu-btn');
const userDropdown = document.getElementById('user-dropdown');

if (userMenuBtn) {
    userMenuBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        userDropdown.classList.toggle('hidden');
    });

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.user-menu')) {
            userDropdown.classList.add('hidden');
        }
    });
}

// ========== SCROLL EFFECT ==========
window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 20) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ========== MOBILE NAV ==========
const navToggle = document.getElementById('nav-toggle');
if (navToggle) {
    navToggle.addEventListener('click', function() {
        const navSearch = document.getElementById('nav-search');
        navSearch.style.display = navSearch.style.display === 'block' ? 'none' : 'block';
    });
}

// ========== INITIALIZE ==========
document.addEventListener('DOMContentLoaded', function() {
    // Restore token
    const token = localStorage.getItem('shopnow_token');
    if (token) {
        api.setToken(token);
    }

    updateNavBar();
    hideLoading();
    navigate('home');
});
