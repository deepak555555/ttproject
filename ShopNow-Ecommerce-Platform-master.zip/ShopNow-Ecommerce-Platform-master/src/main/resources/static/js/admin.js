// ============================================
// ShopNow E-Commerce - Admin Pages
// ============================================

let adminCurrentTab = 'dashboard';

async function renderAdminPage() {
    const main = document.getElementById('main-content');

    main.innerHTML = `
        <div class="admin-page">
            <div class="page-header"><h1><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h1></div>

            <div class="admin-tabs">
                <button class="admin-tab active" onclick="switchAdminTab('dashboard', this)"><i class="fas fa-chart-line"></i> Dashboard</button>
                <button class="admin-tab" onclick="switchAdminTab('products', this)"><i class="fas fa-box"></i> Products</button>
                <button class="admin-tab" onclick="switchAdminTab('categories', this)"><i class="fas fa-tags"></i> Categories</button>
                <button class="admin-tab" onclick="switchAdminTab('orders', this)"><i class="fas fa-shopping-bag"></i> Orders</button>
                <button class="admin-tab" onclick="switchAdminTab('users', this)"><i class="fas fa-users"></i> Users</button>
                <button class="admin-tab" onclick="switchAdminTab('coupons', this)"><i class="fas fa-ticket-alt"></i> Coupons</button>
                <button class="admin-tab" onclick="switchAdminTab('inventory', this)"><i class="fas fa-warehouse"></i> Inventory</button>
            </div>

            <div id="admin-content"></div>
        </div>
    `;

    loadAdminTab('dashboard');
}

function switchAdminTab(tab, el) {
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    if (el) el.classList.add('active');
    adminCurrentTab = tab;
    loadAdminTab(tab);
}

async function loadAdminTab(tab) {
    const content = document.getElementById('admin-content');
    if (!content) return;

    switch (tab) {
        case 'dashboard': await loadAdminDashboard(content); break;
        case 'products': await loadAdminProducts(content); break;
        case 'categories': await loadAdminCategories(content); break;
        case 'orders': await loadAdminOrders(content); break;
        case 'users': await loadAdminUsers(content); break;
        case 'coupons': await loadAdminCoupons(content); break;
        case 'inventory': await loadAdminInventory(content); break;
    }
}

// ========== DASHBOARD TAB ==========
async function loadAdminDashboard(container) {
    try {
        const result = await api.getDashboard();
        const stats = result.data;

        container.innerHTML = `
            <div class="stat-cards fade-in">
                <div class="stat-card purple">
                    <div class="stat-icon"><i class="fas fa-box"></i></div>
                    <div class="stat-value">${stats.totalProducts}</div>
                    <div class="stat-label">Total Products</div>
                </div>
                <div class="stat-card pink">
                    <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                    <div class="stat-value">${stats.totalOrders}</div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card cyan">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-value">${stats.totalCustomers}</div>
                    <div class="stat-label">Customers</div>
                </div>
                <div class="stat-card green">
                    <div class="stat-icon"><i class="fas fa-rupee-sign"></i></div>
                    <div class="stat-value">${formatPrice(stats.totalRevenue)}</div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:1.5rem;margin-bottom:2rem">
                <div class="card">
                    <div class="card-body">
                        <h4 style="color:var(--text-muted);font-size:0.85rem;margin-bottom:0.5rem">Today's Revenue</h4>
                        <div style="font-size:1.5rem;font-weight:800;color:var(--success)">${formatPrice(stats.todayRevenue)}</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color:var(--text-muted);font-size:0.85rem;margin-bottom:0.5rem">This Month</h4>
                        <div style="font-size:1.5rem;font-weight:800;color:var(--accent)">${formatPrice(stats.monthRevenue)}</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color:var(--text-muted);font-size:0.85rem;margin-bottom:0.5rem">Pending Orders</h4>
                        <div style="font-size:1.5rem;font-weight:800;color:var(--warning)">${stats.pendingOrders}</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color:var(--text-muted);font-size:0.85rem;margin-bottom:0.5rem">Low Stock Items</h4>
                        <div style="font-size:1.5rem;font-weight:800;color:var(--danger)">${stats.lowStockProducts}</div>
                    </div>
                </div>
            </div>

            ${stats.ordersByStatus ? `
                <div class="card" style="margin-bottom:2rem">
                    <div class="card-body">
                        <h3 style="color:var(--text-white);margin-bottom:1.5rem"><i class="fas fa-chart-bar" style="color:var(--primary-light)"></i> Orders by Status</h3>
                        <div style="display:flex;gap:1rem;flex-wrap:wrap">
                            ${Object.entries(stats.ordersByStatus).map(([status, count]) => `
                                <div style="flex:1;min-width:100px;padding:1rem;text-align:center;border-radius:var(--radius-md);background:var(--bg-input)">
                                    <div style="font-size:1.5rem;font-weight:700;color:var(--text-white)">${count}</div>
                                    <span class="order-status status-${status}">${status}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            ` : ''}
        `;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load dashboard</h3><p>${e.message}</p></div>`;
    }
}

// ========== PRODUCTS TAB ==========
async function loadAdminProducts(container, page = 0) {
    try {
        const data = await api.getProducts(page, 10, 'createdAt', 'desc');
        const products = data.content || [];
        const categories = await api.getCategories();

        container.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
                <h3 style="color:var(--text-white)">Products (${data.totalElements})</h3>
                <button class="btn btn-primary" onclick="showAddProductModal()"><i class="fas fa-plus"></i> Add Product</button>
            </div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr>
                        <th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th>
                    </tr></thead>
                    <tbody>
                        ${products.map(p => `
                            <tr>
                                <td>
                                    <div style="display:flex;align-items:center;gap:0.75rem">
                                        <img src="${getProductImageUrl(p)}" style="width:45px;height:45px;border-radius:8px;object-fit:cover" onerror="this.src='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=100'">
                                        <div>
                                            <div style="font-weight:600;color:var(--text-white)">${escapeHtml(p.name)}</div>
                                            <div style="font-size:0.75rem;color:var(--text-muted)">ID: ${p.id}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>${escapeHtml(p.category?.name || '-')}</td>
                                <td style="font-weight:600">${formatPrice(p.price)}</td>
                                <td><span class="order-status ${p.stock <= 10 ? (p.stock === 0 ? 'status-CANCELLED' : 'status-PENDING') : 'status-DELIVERED'}">${p.stock}</span></td>
                                <td><span class="order-status ${p.active ? 'status-DELIVERED' : 'status-CANCELLED'}">${p.active ? 'Active' : 'Inactive'}</span></td>
                                <td>
                                    <div style="display:flex;gap:0.5rem">
                                        <button class="btn btn-outline btn-sm" onclick="showEditProductModal(${p.id})"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteAdminProduct(${p.id})"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            ${createPagination(data.number, data.totalPages, 'loadAdminProductsPage')}
        `;

        // Store categories for modal
        window._adminCategories = categories;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load products</h3></div>`;
    }
}

function loadAdminProductsPage(page) {
    loadAdminProducts(document.getElementById('admin-content'), page);
}

function showAddProductModal() {
    const cats = window._adminCategories || [];
    const catOpts = cats.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');

    showModal('Add Product', `
        <form id="add-product-form">
            <div class="form-group"><label>Name</label><input type="text" class="form-control" id="ap-name" required></div>
            <div class="form-group"><label>Description</label><textarea class="form-control" id="ap-desc" rows="3"></textarea></div>
            <div class="form-group"><label>Category</label><select class="form-control" id="ap-category"><option value="">Select</option>${catOpts}</select></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                <div class="form-group"><label>Price (₹)</label><input type="number" class="form-control" id="ap-price" step="0.01" required></div>
                <div class="form-group"><label>Stock</label><input type="number" class="form-control" id="ap-stock" required></div>
            </div>
            <div class="form-group"><label>Image</label><input type="file" class="form-control" id="ap-image" accept="image/*"></div>
        </form>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitAddProduct()"><i class="fas fa-plus"></i> Add Product</button>
    `);
}

async function submitAddProduct() {
    const formData = new FormData();
    formData.append('name', document.getElementById('ap-name').value);
    formData.append('description', document.getElementById('ap-desc').value);
    formData.append('price', document.getElementById('ap-price').value);
    formData.append('stock', document.getElementById('ap-stock').value);

    const catId = document.getElementById('ap-category').value;
    if (catId) formData.append('categoryId', catId);

    const imageFile = document.getElementById('ap-image').files[0];
    if (imageFile) formData.append('image', imageFile);

    try {
        await api.createProduct(formData);
        closeModal();
        showToast('Product created!', 'success');
        loadAdminTab('products');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function showEditProductModal(productId) {
    const product = await api.getProduct(productId);
    const cats = window._adminCategories || [];
    const catOpts = cats.map(c => `<option value="${c.id}" ${product.category?.id === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('');

    showModal('Edit Product', `
        <form id="edit-product-form">
            <div class="form-group"><label>Name</label><input type="text" class="form-control" id="ep-name" value="${escapeHtml(product.name)}" required></div>
            <div class="form-group"><label>Description</label><textarea class="form-control" id="ep-desc" rows="3">${escapeHtml(product.description || '')}</textarea></div>
            <div class="form-group"><label>Category</label><select class="form-control" id="ep-category"><option value="">Select</option>${catOpts}</select></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                <div class="form-group"><label>Price (₹)</label><input type="number" class="form-control" id="ep-price" value="${product.price}" step="0.01" required></div>
                <div class="form-group"><label>Stock</label><input type="number" class="form-control" id="ep-stock" value="${product.stock}" required></div>
            </div>
            <div class="form-group"><label>New Image (optional)</label><input type="file" class="form-control" id="ep-image" accept="image/*"></div>
        </form>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitEditProduct(${product.id})"><i class="fas fa-save"></i> Save</button>
    `);
}

async function submitEditProduct(id) {
    const formData = new FormData();
    formData.append('name', document.getElementById('ep-name').value);
    formData.append('description', document.getElementById('ep-desc').value);
    formData.append('price', document.getElementById('ep-price').value);
    formData.append('stock', document.getElementById('ep-stock').value);

    const catId = document.getElementById('ep-category').value;
    if (catId) formData.append('categoryId', catId);

    const imageFile = document.getElementById('ep-image').files[0];
    if (imageFile) formData.append('image', imageFile);

    try {
        await api.updateProduct(id, formData);
        closeModal();
        showToast('Product updated!', 'success');
        loadAdminTab('products');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function deleteAdminProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
        await api.deleteProduct(id);
        showToast('Product deleted', 'success');
        loadAdminTab('products');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== CATEGORIES TAB ==========
async function loadAdminCategories(container) {
    try {
        const categories = await api.getCategories();

        container.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem">
                <h3 style="color:var(--text-white)">Categories (${categories.length})</h3>
                <button class="btn btn-primary" onclick="showAddCategoryModal()"><i class="fas fa-plus"></i> Add Category</button>
            </div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${categories.map(c => `
                            <tr>
                                <td>${c.id}</td>
                                <td style="font-weight:600;color:var(--text-white)">${escapeHtml(c.name)}</td>
                                <td>${escapeHtml(c.description || '-')}</td>
                                <td>
                                    <div style="display:flex;gap:0.5rem">
                                        <button class="btn btn-outline btn-sm" onclick="showEditCategoryModal(${c.id}, '${escapeHtml(c.name)}', '${escapeHtml(c.description || '')}')"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteAdminCategory(${c.id})"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load categories</h3></div>`;
    }
}

function showAddCategoryModal() {
    showModal('Add Category', `
        <div class="form-group"><label>Name</label><input type="text" class="form-control" id="ac-name" required></div>
        <div class="form-group"><label>Description</label><textarea class="form-control" id="ac-desc" rows="2"></textarea></div>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitAddCategory()"><i class="fas fa-plus"></i> Add</button>
    `);
}

async function submitAddCategory() {
    try {
        await api.createCategory({
            name: document.getElementById('ac-name').value,
            description: document.getElementById('ac-desc').value
        });
        closeModal();
        showToast('Category created!', 'success');
        loadAdminTab('categories');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

function showEditCategoryModal(id, name, desc) {
    showModal('Edit Category', `
        <div class="form-group"><label>Name</label><input type="text" class="form-control" id="ec-name" value="${name}" required></div>
        <div class="form-group"><label>Description</label><textarea class="form-control" id="ec-desc" rows="2">${desc}</textarea></div>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitEditCategory(${id})"><i class="fas fa-save"></i> Save</button>
    `);
}

async function submitEditCategory(id) {
    try {
        await api.updateCategory(id, {
            name: document.getElementById('ec-name').value,
            description: document.getElementById('ec-desc').value
        });
        closeModal();
        showToast('Category updated!', 'success');
        loadAdminTab('categories');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function deleteAdminCategory(id) {
    if (!confirm('Delete this category?')) return;
    try {
        await api.deleteCategory(id);
        showToast('Category deleted', 'success');
        loadAdminTab('categories');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== ORDERS TAB ==========
async function loadAdminOrders(container, page = 0) {
    try {
        const result = await api.getAllOrders(page, 10);
        const data = result.data;
        const orders = data.content || [];

        container.innerHTML = `
            <h3 style="color:var(--text-white);margin-bottom:1.5rem">All Orders (${data.totalElements})</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${orders.map(o => `
                            <tr>
                                <td style="font-weight:600">#${o.id}</td>
                                <td>${escapeHtml(o.user?.name || 'N/A')}<br><small style="color:var(--text-muted)">${escapeHtml(o.user?.email || '')}</small></td>
                                <td style="font-weight:600">${formatPrice(o.totalPrice)}</td>
                                <td><span class="order-status status-${o.status}">${o.status}</span></td>
                                <td>${formatDate(o.createdAt)}</td>
                                <td>
                                    <select class="form-control" style="min-width:130px;padding:0.4rem;font-size:0.8rem" onchange="updateAdminOrderStatus(${o.id}, this.value)">
                                        ${['PENDING','CONFIRMED','SHIPPED','DELIVERED','CANCELLED'].map(s =>
                                            `<option value="${s}" ${o.status === s ? 'selected' : ''}>${s}</option>`
                                        ).join('')}
                                    </select>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            ${createPagination(data.number, data.totalPages, 'loadAdminOrdersPage')}
        `;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load orders</h3></div>`;
    }
}

function loadAdminOrdersPage(page) {
    loadAdminOrders(document.getElementById('admin-content'), page);
}

async function updateAdminOrderStatus(orderId, status) {
    try {
        await api.updateOrderStatus(orderId, status);
        showToast(`Order #${orderId} status updated to ${status}`, 'success');
    } catch (e) {
        showToast(e.message, 'error');
        loadAdminTab('orders');
    }
}

// ========== USERS TAB ==========
async function loadAdminUsers(container) {
    try {
        const result = await api.getAllUsers();
        const users = result.data || [];

        container.innerHTML = `
            <h3 style="color:var(--text-white);margin-bottom:1.5rem">Users (${users.length})</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${users.map(u => `
                            <tr>
                                <td>${u.id}</td>
                                <td style="font-weight:600;color:var(--text-white)">${escapeHtml(u.name)}</td>
                                <td>${escapeHtml(u.email)}</td>
                                <td><span class="order-status ${u.role === 'ADMIN' ? 'status-SHIPPED' : 'status-CONFIRMED'}">${u.role}</span></td>
                                <td><span class="order-status ${u.status === 'ACTIVE' ? 'status-DELIVERED' : 'status-CANCELLED'}">${u.status}</span></td>
                                <td>${formatDate(u.createdAt)}</td>
                                <td>
                                    ${u.role !== 'ADMIN' ? `
                                        <button class="btn ${u.status === 'ACTIVE' ? 'btn-warning' : 'btn-success'} btn-sm" onclick="toggleAdminUserStatus(${u.id})">
                                            ${u.status === 'ACTIVE' ? '<i class="fas fa-ban"></i> Block' : '<i class="fas fa-check"></i> Unblock'}
                                        </button>
                                    ` : '<span style="color:var(--text-muted);font-size:0.8rem">N/A</span>'}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load users</h3></div>`;
    }
}

async function toggleAdminUserStatus(userId) {
    try {
        await api.toggleUserStatus(userId);
        showToast('User status updated', 'success');
        loadAdminTab('users');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== COUPONS TAB ==========
async function loadAdminCoupons(container) {
    try {
        const result = await api.getCoupons();
        const coupons = result.data || [];

        container.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem">
                <h3 style="color:var(--text-white)">Coupons (${coupons.length})</h3>
                <button class="btn btn-primary" onclick="showAddCouponModal()"><i class="fas fa-plus"></i> Add Coupon</button>
            </div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Code</th><th>Discount</th><th>Min Order</th><th>Max Discount</th><th>Expiry</th><th>Usage</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${coupons.map(c => `
                            <tr>
                                <td style="font-weight:700;color:var(--primary-light)">${escapeHtml(c.code)}</td>
                                <td>${c.discount}%</td>
                                <td>${c.minOrderAmount ? formatPrice(c.minOrderAmount) : '-'}</td>
                                <td>${c.maxDiscountAmount ? formatPrice(c.maxDiscountAmount) : '-'}</td>
                                <td>${c.expiryDate}</td>
                                <td>${c.timesUsed}${c.usageLimit ? '/' + c.usageLimit : ''}</td>
                                <td><span class="order-status ${c.active ? 'status-DELIVERED' : 'status-CANCELLED'}">${c.active ? 'Active' : 'Inactive'}</span></td>
                                <td>
                                    <div style="display:flex;gap:0.5rem">
                                        <button class="btn btn-outline btn-sm" onclick="showEditCouponModal(${c.id})"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteAdminCoupon(${c.id})"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        window._adminCoupons = coupons;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load coupons</h3></div>`;
    }
}

function showAddCouponModal() {
    showModal('Add Coupon', `
        <div class="form-group"><label>Code</label><input type="text" class="form-control" id="acp-code" required placeholder="e.g., SAVE20"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
            <div class="form-group"><label>Discount (%)</label><input type="number" class="form-control" id="acp-discount" min="1" max="100" required></div>
            <div class="form-group"><label>Usage Limit</label><input type="number" class="form-control" id="acp-limit" placeholder="Optional"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
            <div class="form-group"><label>Min Order (₹)</label><input type="number" class="form-control" id="acp-min" value="0"></div>
            <div class="form-group"><label>Max Discount (₹)</label><input type="number" class="form-control" id="acp-max" placeholder="Optional"></div>
        </div>
        <div class="form-group"><label>Expiry Date</label><input type="date" class="form-control" id="acp-expiry" required></div>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitAddCoupon()"><i class="fas fa-plus"></i> Create</button>
    `);
}

async function submitAddCoupon() {
    try {
        await api.createCoupon({
            code: document.getElementById('acp-code').value,
            discount: parseFloat(document.getElementById('acp-discount').value),
            minOrderAmount: parseFloat(document.getElementById('acp-min').value) || 0,
            maxDiscountAmount: document.getElementById('acp-max').value ? parseFloat(document.getElementById('acp-max').value) : null,
            usageLimit: document.getElementById('acp-limit').value ? parseInt(document.getElementById('acp-limit').value) : null,
            expiryDate: document.getElementById('acp-expiry').value,
            active: true
        });
        closeModal();
        showToast('Coupon created!', 'success');
        loadAdminTab('coupons');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function showEditCouponModal(id) {
    const coupon = (window._adminCoupons || []).find(c => c.id === id);
    if (!coupon) return;

    showModal('Edit Coupon', `
        <div class="form-group"><label>Code</label><input type="text" class="form-control" id="ecp-code" value="${coupon.code}" required></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
            <div class="form-group"><label>Discount (%)</label><input type="number" class="form-control" id="ecp-discount" value="${coupon.discount}" min="1" max="100" required></div>
            <div class="form-group"><label>Usage Limit</label><input type="number" class="form-control" id="ecp-limit" value="${coupon.usageLimit || ''}"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
            <div class="form-group"><label>Min Order (₹)</label><input type="number" class="form-control" id="ecp-min" value="${coupon.minOrderAmount || 0}"></div>
            <div class="form-group"><label>Max Discount (₹)</label><input type="number" class="form-control" id="ecp-max" value="${coupon.maxDiscountAmount || ''}"></div>
        </div>
        <div class="form-group"><label>Expiry Date</label><input type="date" class="form-control" id="ecp-expiry" value="${coupon.expiryDate}" required></div>
        <div class="form-group">
            <label><input type="checkbox" id="ecp-active" ${coupon.active ? 'checked' : ''}> Active</label>
        </div>
    `, `
        <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitEditCoupon(${id})"><i class="fas fa-save"></i> Save</button>
    `);
}

async function submitEditCoupon(id) {
    try {
        await api.updateCoupon(id, {
            code: document.getElementById('ecp-code').value,
            discount: parseFloat(document.getElementById('ecp-discount').value),
            minOrderAmount: parseFloat(document.getElementById('ecp-min').value) || 0,
            maxDiscountAmount: document.getElementById('ecp-max').value ? parseFloat(document.getElementById('ecp-max').value) : null,
            usageLimit: document.getElementById('ecp-limit').value ? parseInt(document.getElementById('ecp-limit').value) : null,
            expiryDate: document.getElementById('ecp-expiry').value,
            active: document.getElementById('ecp-active').checked
        });
        closeModal();
        showToast('Coupon updated!', 'success');
        loadAdminTab('coupons');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function deleteAdminCoupon(id) {
    if (!confirm('Delete this coupon?')) return;
    try {
        await api.deleteCoupon(id);
        showToast('Coupon deleted', 'success');
        loadAdminTab('coupons');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== INVENTORY TAB ==========
async function loadAdminInventory(container) {
    try {
        const result = await api.getLowStock(10);
        const lowStock = result.data || [];
        const allProducts = await api.getProducts(0, 100, 'stock', 'asc');
        const products = allProducts.content || [];

        container.innerHTML = `
            ${lowStock.length > 0 ? `
                <div class="card" style="margin-bottom:2rem;border-color:var(--warning)">
                    <div class="card-body">
                        <h3 style="color:var(--warning);margin-bottom:1rem"><i class="fas fa-exclamation-triangle"></i> Low Stock Alert (${lowStock.length} items)</h3>
                        <div style="display:grid;gap:0.75rem">
                            ${lowStock.map(p => `
                                <div style="display:flex;justify-content:space-between;align-items:center;padding:0.75rem;background:var(--bg-input);border-radius:var(--radius-sm)">
                                    <div>
                                        <strong style="color:var(--text-white)">${escapeHtml(p.name)}</strong>
                                        <span style="margin-left:0.5rem" class="order-status ${p.stock === 0 ? 'status-CANCELLED' : 'status-PENDING'}">${p.stock} left</span>
                                    </div>
                                    <div style="display:flex;gap:0.5rem;align-items:center">
                                        <input type="number" class="form-control" style="width:80px;padding:0.4rem" id="inv-${p.id}" value="${p.stock}" min="0">
                                        <button class="btn btn-success btn-sm" onclick="updateInventory(${p.id})"><i class="fas fa-save"></i></button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            ` : '<div class="card" style="margin-bottom:2rem"><div class="card-body"><p style="color:var(--success)"><i class="fas fa-check-circle"></i> All products are well-stocked!</p></div></div>'}

            <h3 style="color:var(--text-white);margin-bottom:1.5rem">All Product Stock</h3>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Product</th><th>Current Stock</th><th>Status</th><th>Update</th></tr></thead>
                    <tbody>
                        ${products.map(p => `
                            <tr>
                                <td style="font-weight:600;color:var(--text-white)">${escapeHtml(p.name)}</td>
                                <td>${p.stock}</td>
                                <td><span class="order-status ${p.stock === 0 ? 'status-CANCELLED' : p.stock <= 10 ? 'status-PENDING' : 'status-DELIVERED'}">${p.stock === 0 ? 'Out of Stock' : p.stock <= 10 ? 'Low Stock' : 'In Stock'}</span></td>
                                <td>
                                    <div style="display:flex;gap:0.5rem;align-items:center">
                                        <input type="number" class="form-control" style="width:80px;padding:0.4rem" id="inv-all-${p.id}" value="${p.stock}" min="0">
                                        <button class="btn btn-outline btn-sm" onclick="updateInventoryAll(${p.id})"><i class="fas fa-sync"></i></button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (e) {
        container.innerHTML = `<div class="empty-state"><h3>Failed to load inventory</h3></div>`;
    }
}

async function updateInventory(productId) {
    const stock = parseInt(document.getElementById(`inv-${productId}`).value);
    try {
        await api.updateStock(productId, stock);
        showToast('Stock updated!', 'success');
        loadAdminTab('inventory');
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function updateInventoryAll(productId) {
    const stock = parseInt(document.getElementById(`inv-all-${productId}`).value);
    try {
        await api.updateStock(productId, stock);
        showToast('Stock updated!', 'success');
    } catch (e) {
        showToast(e.message, 'error');
    }
}
