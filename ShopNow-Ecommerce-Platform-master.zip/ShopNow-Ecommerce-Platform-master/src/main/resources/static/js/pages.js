// ============================================
// ShopNow E-Commerce - Page Renderers
// ============================================

// ========== HOME PAGE ==========
async function renderHomePage() {
    const main = document.getElementById('main-content');

    main.innerHTML = `
        <section class="hero">
            <div class="hero-content fade-in">
                <h1>Discover Premium Products at Unbeatable Prices</h1>
                <p>Shop from thousands of quality products. Fast delivery, secure payments, and hassle-free returns.</p>
                <div class="hero-actions">
                    <button class="btn btn-primary btn-lg" onclick="document.getElementById('products-section').scrollIntoView({behavior:'smooth'})">
                        <i class="fas fa-shopping-bag"></i> Shop Now
                    </button>
                    <button class="btn btn-outline btn-lg" onclick="navigate('register')">
                        <i class="fas fa-user-plus"></i> Join Free
                    </button>
                </div>
                <div class="hero-stats">
                    <div class="hero-stat"><div class="stat-number" id="hero-products">0</div><div class="stat-label">Products</div></div>
                    <div class="hero-stat"><div class="stat-number" id="hero-categories">0</div><div class="stat-label">Categories</div></div>
                    <div class="hero-stat"><div class="stat-number">24/7</div><div class="stat-label">Support</div></div>
                    <div class="hero-stat"><div class="stat-number">Free</div><div class="stat-label">Delivery</div></div>
                </div>
            </div>
        </section>

        <div id="category-bar" class="category-bar"></div>

        <div class="filter-bar" id="filter-bar">
            <select id="filter-sort" class="form-control" onchange="applyFilters()" style="min-width:160px">
                <option value="createdAt-desc">Latest First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name-asc">Name: A-Z</option>
            </select>
            <input type="number" id="filter-min-price" placeholder="Min Price" class="form-control" style="width:130px" onchange="applyFilters()">
            <input type="number" id="filter-max-price" placeholder="Max Price" class="form-control" style="width:130px" onchange="applyFilters()">
            <span class="result-count" id="result-count"></span>
        </div>

        <section id="products-section">
            <div class="product-grid" id="product-grid"></div>
            <div id="product-pagination"></div>
        </section>
    `;

    loadCategories();
    loadProducts(0);
}

let currentPage = 0;
let currentCategory = null;
let currentSearch = '';

async function loadCategories() {
    try {
        const categories = await api.getCategories();
        const bar = document.getElementById('category-bar');
        if (!bar) return;

        let html = `<button class="category-chip ${!currentCategory ? 'active' : ''}" onclick="filterByCategory(null)">All</button>`;
        categories.forEach(cat => {
            html += `<button class="category-chip ${currentCategory == cat.id ? 'active' : ''}" onclick="filterByCategory(${cat.id})">${escapeHtml(cat.name)}</button>`;
        });
        bar.innerHTML = html;

        // Update hero stats
        const heroCategories = document.getElementById('hero-categories');
        if (heroCategories) heroCategories.textContent = categories.length;
    } catch (e) {
        console.error('Failed to load categories:', e);
    }
}

async function loadProducts(page = 0) {
    try {
        const grid = document.getElementById('product-grid');
        if (!grid) return;

        const sortVal = document.getElementById('filter-sort')?.value || 'createdAt-desc';
        const [sortBy, direction] = sortVal.split('-');
        const minPrice = document.getElementById('filter-min-price')?.value || '';
        const maxPrice = document.getElementById('filter-max-price')?.value || '';

        let data;
        if (currentSearch) {
            data = await api.searchProducts(currentSearch, page, 12);
        } else {
            const params = { page, size: 12, sortBy, direction };
            if (currentCategory) params.categoryId = currentCategory;
            if (minPrice) params.minPrice = minPrice;
            if (maxPrice) params.maxPrice = maxPrice;
            data = await api.filterProducts(params);
        }

        currentPage = data.number || 0;
        const products = data.content || [];

        const heroProducts = document.getElementById('hero-products');
        if (heroProducts) heroProducts.textContent = data.totalElements || 0;

        const resultCount = document.getElementById('result-count');
        if (resultCount) resultCount.textContent = `${data.totalElements || 0} products found`;

        if (products.length === 0) {
            grid.innerHTML = `
                <div class="empty-state" style="grid-column:1/-1">
                    <i class="fas fa-search"></i>
                    <h3>No products found</h3>
                    <p>Try adjusting your search or filters</p>
                </div>
            `;
            document.getElementById('product-pagination').innerHTML = '';
            return;
        }

        grid.innerHTML = products.map(p => renderProductCard(p)).join('');

        const paginationHtml = createPagination(data.number, data.totalPages, 'loadProducts');
        document.getElementById('product-pagination').innerHTML = paginationHtml;
    } catch (e) {
        console.error('Failed to load products:', e);
    }
}

function renderProductCard(product) {
    const imgUrl = getProductImageUrl(product);
    const catName = product.category ? product.category.name : '';
    const stockHtml = getStockLabel(product.stock);

    return `
        <div class="product-card fade-in" onclick="navigate('product', ${product.id})">
            <div class="product-image">
                <img src="${imgUrl}" alt="${escapeHtml(product.name)}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'">
                <div class="product-actions-overlay">
                    <button class="action-btn" onclick="event.stopPropagation(); toggleWishlist(${product.id}, this)" title="Add to Wishlist">
                        <i class="far fa-heart"></i>
                    </button>
                </div>
                ${stockHtml}
            </div>
            <div class="product-info">
                <div class="product-category">${escapeHtml(catName)}</div>
                <div class="product-name">${escapeHtml(product.name)}</div>
                <div class="product-price-row">
                    <span class="product-price">${formatPrice(product.price)}</span>
                    ${product.stock > 0 ? `
                        <button class="add-cart-btn" onclick="event.stopPropagation(); quickAddToCart(${product.id})" title="Add to Cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

function filterByCategory(categoryId) {
    currentCategory = categoryId;
    currentSearch = '';
    document.getElementById('search-input').value = '';
    loadCategories();
    loadProducts(0);
}

function applyFilters() {
    loadProducts(0);
}

async function quickAddToCart(productId) {
    if (!isLoggedIn()) {
        showToast('Please login to add items to cart', 'warning');
        navigate('login');
        return;
    }
    try {
        const result = await api.addToCart(productId);
        showToast('Added to cart!', 'success');
        updateCartBadge();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function toggleWishlist(productId, btn) {
    if (!isLoggedIn()) {
        showToast('Please login to use wishlist', 'warning');
        navigate('login');
        return;
    }
    try {
        const result = await api.checkWishlist(productId);
        if (result.data === true) {
            await api.removeFromWishlist(productId);
            btn.classList.remove('wishlisted');
            btn.innerHTML = '<i class="far fa-heart"></i>';
            showToast('Removed from wishlist', 'info');
        } else {
            await api.addToWishlist(productId);
            btn.classList.add('wishlisted');
            btn.innerHTML = '<i class="fas fa-heart"></i>';
            showToast('Added to wishlist!', 'success');
        }
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== PRODUCT DETAIL PAGE ==========
async function renderProductDetail(productId) {
    const main = document.getElementById('main-content');
    showLoading();
    try {
        const product = await api.getProduct(productId);
        const imgUrl = getProductImageUrl(product);
        const catName = product.category ? product.category.name : '';
        const stockClass = getStockClass(product.stock);

        let recommendationsHtml = '';
        try {
            const recs = await api.getRecommendations(productId);
            if (recs.length > 0) {
                recommendationsHtml = `
                    <div style="margin-top: 3rem">
                        <h2 style="font-size:1.5rem;font-weight:700;color:var(--text-white);margin-bottom:1.5rem">
                            <i class="fas fa-magic" style="color:var(--primary-light)"></i> You May Also Like
                        </h2>
                        <div class="product-grid">${recs.map(r => renderProductCard(r)).join('')}</div>
                    </div>
                `;
            }
        } catch (e) { /* ignore */ }

        main.innerHTML = `
            <div class="product-detail fade-in">
                <div class="product-detail-grid">
                    <div class="detail-image">
                        <img src="${imgUrl}" alt="${escapeHtml(product.name)}" onerror="this.src='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'">
                    </div>
                    <div class="detail-info">
                        <div class="detail-category">${escapeHtml(catName)}</div>
                        <h1>${escapeHtml(product.name)}</h1>
                        <div class="detail-price">${formatPrice(product.price)}</div>
                        <div class="detail-stock ${stockClass}">
                            <i class="fas fa-${product.stock > 0 ? 'check-circle' : 'times-circle'}"></i>
                            ${product.stock > 0 ? (product.stock <= 10 ? `Only ${product.stock} left in stock` : 'In Stock') : 'Out of Stock'}
                        </div>
                        <div class="detail-description">${escapeHtml(product.description)}</div>

                        ${product.stock > 0 ? `
                            <div class="quantity-control">
                                <span style="font-weight:500;color:var(--text-secondary)">Quantity:</span>
                                <button onclick="changeDetailQty(-1)"><i class="fas fa-minus"></i></button>
                                <span class="qty-value" id="detail-qty">1</span>
                                <button onclick="changeDetailQty(1)"><i class="fas fa-plus"></i></button>
                            </div>
                            <div class="detail-actions">
                                <button class="btn btn-primary btn-lg" onclick="addToCartFromDetail(${product.id})">
                                    <i class="fas fa-shopping-cart"></i> Add to Cart
                                </button>
                                <button class="btn btn-outline btn-lg" onclick="toggleWishlistDetail(${product.id}, this)" id="detail-wishlist-btn">
                                    <i class="far fa-heart"></i> Wishlist
                                </button>
                            </div>
                        ` : `
                            <button class="btn btn-secondary btn-lg" disabled>
                                <i class="fas fa-times"></i> Out of Stock
                            </button>
                        `}
                    </div>
                </div>
                ${recommendationsHtml}
            </div>
        `;

        // Check wishlist status
        if (isLoggedIn()) {
            try {
                const wishResult = await api.checkWishlist(productId);
                if (wishResult.data === true) {
                    const btn = document.getElementById('detail-wishlist-btn');
                    if (btn) {
                        btn.innerHTML = '<i class="fas fa-heart"></i> In Wishlist';
                        btn.classList.add('wishlisted');
                    }
                }
            } catch (e) { /* ignore */ }
        }
    } catch (e) {
        main.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Product not found</h3><button class="btn btn-primary" onclick="navigate('home')">Back to Shop</button></div>`;
    }
    hideLoading();
}

function changeDetailQty(delta) {
    const el = document.getElementById('detail-qty');
    let qty = parseInt(el.textContent) + delta;
    if (qty < 1) qty = 1;
    if (qty > 99) qty = 99;
    el.textContent = qty;
}

async function addToCartFromDetail(productId) {
    if (!isLoggedIn()) {
        showToast('Please login to add items to cart', 'warning');
        navigate('login');
        return;
    }
    const qty = parseInt(document.getElementById('detail-qty').textContent);
    try {
        await api.addToCart(productId, qty);
        showToast('Added to cart!', 'success');
        updateCartBadge();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function toggleWishlistDetail(productId, btn) {
    await toggleWishlist(productId, btn);
}

// ========== LOGIN PAGE ==========
function renderLoginPage() {
    document.getElementById('main-content').innerHTML = `
        <div class="auth-page">
            <div class="auth-card fade-in">
                <h2>Welcome Back</h2>
                <p class="auth-subtitle">Sign in to your ShopNow account</p>
                <form onsubmit="handleLogin(event)">
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" class="form-control" id="login-email" placeholder="you@example.com" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" id="login-password" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg" id="login-btn">
                        <i class="fas fa-sign-in-alt"></i> Sign In
                    </button>
                </form>
                <div class="auth-switch">
                    Don't have an account? <a href="#" onclick="navigate('register')">Create one</a>
                </div>
                <div style="margin-top:1rem;text-align:center;font-size:0.8rem;color:var(--text-muted)">
                    <p>Demo Admin: admin@shopnow.com / admin123</p>
                    <p>Demo Customer: john@example.com / customer123</p>
                </div>
            </div>
        </div>
    `;
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const btn = document.getElementById('login-btn');

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';

    try {
        const result = await api.login(email, password);
        const authData = result.data;
        api.setToken(authData.token);
        localStorage.setItem('shopnow_user', JSON.stringify(authData));
        showToast('Login successful! Welcome back, ' + authData.name, 'success');
        updateNavBar();
        navigate('home');
    } catch (e) {
        showToast(e.message || 'Invalid credentials', 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
    }
}

// ========== REGISTER PAGE ==========
function renderRegisterPage() {
    document.getElementById('main-content').innerHTML = `
        <div class="auth-page">
            <div class="auth-card fade-in">
                <h2>Create Account</h2>
                <p class="auth-subtitle">Join ShopNow and start shopping</p>
                <form onsubmit="handleRegister(event)">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" class="form-control" id="reg-name" placeholder="Your full name" required minlength="2">
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" class="form-control" id="reg-email" placeholder="you@example.com" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" id="reg-password" placeholder="Create a password (min 6 chars)" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label>Phone (Optional)</label>
                        <input type="tel" class="form-control" id="reg-phone" placeholder="Your phone number">
                    </div>
                    <div class="form-group">
                        <label>Address (Optional)</label>
                        <textarea class="form-control" id="reg-address" placeholder="Your delivery address" rows="2"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg" id="reg-btn">
                        <i class="fas fa-user-plus"></i> Create Account
                    </button>
                </form>
                <div class="auth-switch">
                    Already have an account? <a href="#" onclick="navigate('login')">Sign in</a>
                </div>
            </div>
        </div>
    `;
}

async function handleRegister(e) {
    e.preventDefault();
    const btn = document.getElementById('reg-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';

    try {
        const result = await api.register({
            name: document.getElementById('reg-name').value,
            email: document.getElementById('reg-email').value,
            password: document.getElementById('reg-password').value,
            phone: document.getElementById('reg-phone').value,
            address: document.getElementById('reg-address').value
        });
        const authData = result.data;
        api.setToken(authData.token);
        localStorage.setItem('shopnow_user', JSON.stringify(authData));
        showToast('Account created! Welcome, ' + authData.name, 'success');
        updateNavBar();
        navigate('home');
    } catch (e) {
        showToast(e.message || 'Registration failed', 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-user-plus"></i> Create Account';
    }
}

// ========== CART PAGE ==========
async function renderCartPage() {
    const main = document.getElementById('main-content');
    showLoading();

    try {
        const result = await api.getCart();
        const cartData = result.data;
        const cart = cartData.cart;
        const items = cart.items || [];
        const total = cartData.total;

        let html = `<div class="cart-page"><div class="page-header"><h1><i class="fas fa-shopping-cart"></i> Your Cart</h1></div>`;

        if (items.length === 0) {
            html += `
                <div class="empty-state">
                    <i class="fas fa-shopping-cart"></i>
                    <h3>Your cart is empty</h3>
                    <p>Add some amazing products to your cart!</p>
                    <button class="btn btn-primary" onclick="navigate('home')"><i class="fas fa-shopping-bag"></i> Start Shopping</button>
                </div>
            `;
        } else {
            html += '<div id="cart-items">';
            items.forEach(item => {
                const imgUrl = getProductImageUrl(item.product);
                html += `
                    <div class="cart-item fade-in">
                        <div class="cart-item-image">
                            <img src="${imgUrl}" alt="${escapeHtml(item.product.name)}" onerror="this.src='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'">
                        </div>
                        <div class="cart-item-info">
                            <div class="cart-item-name" style="cursor:pointer" onclick="navigate('product', ${item.product.id})">${escapeHtml(item.product.name)}</div>
                            <div class="cart-item-price">${formatPrice(item.product.price)}</div>
                        </div>
                        <div class="cart-item-actions">
                            <div class="quantity-control">
                                <button onclick="updateCartQty(${item.product.id}, ${item.quantity - 1})"><i class="fas fa-minus"></i></button>
                                <span class="qty-value">${item.quantity}</span>
                                <button onclick="updateCartQty(${item.product.id}, ${item.quantity + 1})"><i class="fas fa-plus"></i></button>
                            </div>
                            <strong style="min-width:100px;text-align:right;color:var(--text-white)">${formatPrice(item.product.price * item.quantity)}</strong>
                            <button class="btn btn-icon btn-outline" onclick="removeCartItem(${item.product.id})" title="Remove">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `;
            });
            html += '</div>';

            html += `
                <div class="cart-summary">
                    <div class="coupon-input">
                        <input type="text" id="coupon-code" placeholder="Enter coupon code" class="form-control">
                        <button class="btn btn-outline" onclick="applyCoupon()">Apply</button>
                    </div>
                    <div id="coupon-result"></div>
                    <div class="summary-row">
                        <span>Subtotal (${items.length} items)</span>
                        <span>${formatPrice(total)}</span>
                    </div>
                    <div class="summary-row" id="discount-row" style="display:none">
                        <span style="color:var(--success)">Discount</span>
                        <span style="color:var(--success)" id="discount-amount">-₹0</span>
                    </div>
                    <div class="summary-row">
                        <span>Delivery</span>
                        <span style="color:var(--success)">FREE</span>
                    </div>
                    <div class="summary-row summary-total">
                        <span>Total</span>
                        <span id="cart-total">${formatPrice(total)}</span>
                    </div>
                    <button class="btn btn-primary btn-block btn-lg" style="margin-top:1rem" onclick="navigate('checkout')">
                        <i class="fas fa-lock"></i> Proceed to Checkout
                    </button>
                </div>
            `;
        }

        html += '</div>';
        main.innerHTML = html;
    } catch (e) {
        main.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Failed to load cart</h3><p>${e.message}</p></div>`;
    }
    hideLoading();
}

async function updateCartQty(productId, qty) {
    try {
        if (qty <= 0) {
            await api.removeFromCart(productId);
        } else {
            await api.updateCartItem(productId, qty);
        }
        renderCartPage();
        updateCartBadge();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function removeCartItem(productId) {
    try {
        await api.removeFromCart(productId);
        showToast('Item removed from cart', 'info');
        renderCartPage();
        updateCartBadge();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

let appliedCoupon = null;
let discountAmount = 0;

async function applyCoupon() {
    const code = document.getElementById('coupon-code').value.trim();
    if (!code) {
        showToast('Please enter a coupon code', 'warning');
        return;
    }

    try {
        const cartResult = await api.getCart();
        const total = cartResult.data.total;
        const result = await api.validateCoupon(code, total);
        const couponData = result.data;

        appliedCoupon = code;
        discountAmount = couponData.discount;

        document.getElementById('coupon-result').innerHTML = `
            <div style="padding:0.5rem;border-radius:var(--radius-sm);background:rgba(16,185,129,0.1);color:var(--success);font-size:0.85rem;margin-bottom:0.5rem">
                <i class="fas fa-check-circle"></i> Coupon applied! You save ${formatPrice(discountAmount)}
            </div>
        `;
        document.getElementById('discount-row').style.display = 'flex';
        document.getElementById('discount-amount').textContent = '-' + formatPrice(discountAmount);
        document.getElementById('cart-total').textContent = formatPrice(couponData.finalTotal);
        showToast('Coupon applied!', 'success');
    } catch (e) {
        appliedCoupon = null;
        discountAmount = 0;
        document.getElementById('coupon-result').innerHTML = `
            <div style="padding:0.5rem;border-radius:var(--radius-sm);background:rgba(239,68,68,0.1);color:var(--danger);font-size:0.85rem;margin-bottom:0.5rem">
                <i class="fas fa-times-circle"></i> ${e.message}
            </div>
        `;
        showToast(e.message, 'error');
    }
}

// ========== CHECKOUT PAGE ==========
async function renderCheckoutPage() {
    const main = document.getElementById('main-content');
    showLoading();

    try {
        const cartResult = await api.getCart();
        const cartData = cartResult.data;
        const items = cartData.cart.items || [];
        const total = cartData.total;

        if (items.length === 0) {
            navigate('cart');
            return;
        }

        const user = JSON.parse(localStorage.getItem('shopnow_user'));

        main.innerHTML = `
            <div class="checkout-page fade-in">
                <div class="page-header"><h1><i class="fas fa-lock"></i> Checkout</h1></div>

                <div class="checkout-section">
                    <h3><i class="fas fa-map-marker-alt"></i> Shipping Address</h3>
                    <textarea class="form-control" id="shipping-address" rows="3" placeholder="Enter your delivery address">${escapeHtml(user?.address || '')}</textarea>
                </div>

                <div class="checkout-section">
                    <h3><i class="fas fa-credit-card"></i> Payment Method</h3>
                    <div class="payment-options">
                        <div class="payment-option selected" onclick="selectPayment(this, 'COD')">
                            <i class="fas fa-money-bill-wave"></i>
                            Cash on Delivery
                        </div>
                        <div class="payment-option" onclick="selectPayment(this, 'CARD')">
                            <i class="fas fa-credit-card"></i>
                            Card
                        </div>
                        <div class="payment-option" onclick="selectPayment(this, 'UPI')">
                            <i class="fas fa-mobile-alt"></i>
                            UPI
                        </div>
                        <div class="payment-option" onclick="selectPayment(this, 'NET_BANKING')">
                            <i class="fas fa-university"></i>
                            Net Banking
                        </div>
                    </div>
                    <input type="hidden" id="payment-method" value="COD">
                </div>

                <div class="checkout-section">
                    <h3><i class="fas fa-receipt"></i> Order Summary</h3>
                    ${items.map(item => `
                        <div style="display:flex;justify-content:space-between;padding:0.5rem 0;border-bottom:1px solid var(--border-subtle);font-size:0.9rem">
                            <span>${escapeHtml(item.product.name)} × ${item.quantity}</span>
                            <span style="font-weight:600">${formatPrice(item.product.price * item.quantity)}</span>
                        </div>
                    `).join('')}
                    <div style="display:flex;justify-content:space-between;padding:0.75rem 0;font-size:0.9rem">
                        <span>Subtotal</span><span>${formatPrice(total)}</span>
                    </div>
                    ${appliedCoupon ? `
                        <div style="display:flex;justify-content:space-between;padding:0.5rem 0;color:var(--success);font-size:0.9rem">
                            <span>Discount (${appliedCoupon})</span><span>-${formatPrice(discountAmount)}</span>
                        </div>
                    ` : ''}
                    <div style="display:flex;justify-content:space-between;padding:0.5rem 0;color:var(--success);font-size:0.9rem">
                        <span>Delivery</span><span>FREE</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;padding:1rem 0;font-size:1.3rem;font-weight:800;color:var(--text-white);border-top:1px solid var(--border-color)">
                        <span>Total</span><span>${formatPrice(total - discountAmount)}</span>
                    </div>
                </div>

                <button class="btn btn-primary btn-block btn-lg" id="place-order-btn" onclick="placeOrder()">
                    <i class="fas fa-check-circle"></i> Place Order - ${formatPrice(total - discountAmount)}
                </button>
            </div>
        `;
    } catch (e) {
        showToast(e.message, 'error');
        navigate('cart');
    }
    hideLoading();
}

let selectedPayment = 'COD';

function selectPayment(el, method) {
    document.querySelectorAll('.payment-option').forEach(p => p.classList.remove('selected'));
    el.classList.add('selected');
    selectedPayment = method;
    document.getElementById('payment-method').value = method;
}

async function placeOrder() {
    const address = document.getElementById('shipping-address').value.trim();
    if (!address) {
        showToast('Please enter your shipping address', 'warning');
        return;
    }

    const btn = document.getElementById('place-order-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    try {
        const result = await api.checkout({
            shippingAddress: address,
            couponCode: appliedCoupon || '',
            paymentMethod: selectedPayment
        });

        appliedCoupon = null;
        discountAmount = 0;
        updateCartBadge();

        showToast('Order placed successfully! 🎉', 'success');
        navigate('orders');
    } catch (e) {
        showToast(e.message, 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Place Order';
    }
}

// ========== ORDERS PAGE ==========
async function renderOrdersPage(page = 0) {
    const main = document.getElementById('main-content');
    showLoading();

    try {
        const result = await api.getOrders(page, 10);
        const ordersData = result.data;
        const orders = ordersData.content || [];

        let html = `<div class="page-container"><div class="page-header"><h1><i class="fas fa-box"></i> My Orders</h1></div>`;

        if (orders.length === 0) {
            html += `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>No orders yet</h3>
                    <p>Start shopping to see your orders here!</p>
                    <button class="btn btn-primary" onclick="navigate('home')"><i class="fas fa-shopping-bag"></i> Start Shopping</button>
                </div>
            `;
        } else {
            orders.forEach(order => {
                html += `
                    <div class="order-card fade-in">
                        <div class="order-header">
                            <div>
                                <span class="order-id">Order #${order.id}</span>
                                <span class="order-date" style="margin-left:1rem">${formatDateTime(order.createdAt)}</span>
                            </div>
                            <span class="order-status status-${order.status}">${order.status}</span>
                        </div>
                        <div class="order-items-list">
                            ${(order.items || []).map(item => `
                                <div class="order-item-row">
                                    <span>${escapeHtml(item.product?.name || 'Product')} × ${item.quantity}</span>
                                    <span>${formatPrice(item.price * item.quantity)}</span>
                                </div>
                            `).join('')}
                        </div>
                        <div class="order-footer">
                            <div>
                                <span class="order-total">Total: ${formatPrice(order.totalPrice)}</span>
                                ${order.discountAmount > 0 ? `<span style="font-size:0.8rem;color:var(--success);margin-left:0.5rem">(Saved ${formatPrice(order.discountAmount)})</span>` : ''}
                            </div>
                            <div style="display:flex;gap:0.5rem">
                                ${order.status === 'PENDING' || order.status === 'CONFIRMED' ? `
                                    <button class="btn btn-danger btn-sm" onclick="cancelMyOrder(${order.id})">
                                        <i class="fas fa-times"></i> Cancel
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                `;
            });
        }

        html += createPagination(ordersData.number, ordersData.totalPages, 'loadOrdersPage');
        html += '</div>';
        main.innerHTML = html;
    } catch (e) {
        main.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Failed to load orders</h3></div>`;
    }
    hideLoading();
}

function loadOrdersPage(page) {
    renderOrdersPage(page);
}

async function cancelMyOrder(orderId) {
    if (!confirm('Are you sure you want to cancel this order?')) return;
    try {
        await api.cancelOrder(orderId);
        showToast('Order cancelled successfully', 'success');
        renderOrdersPage();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== WISHLIST PAGE ==========
async function renderWishlistPage() {
    const main = document.getElementById('main-content');
    showLoading();

    try {
        const result = await api.getWishlist();
        const items = result.data || [];

        let html = `<div class="page-container"><div class="page-header"><h1><i class="fas fa-heart"></i> My Wishlist</h1></div>`;

        if (items.length === 0) {
            html += `
                <div class="empty-state">
                    <i class="far fa-heart"></i>
                    <h3>Your wishlist is empty</h3>
                    <p>Save products you love to your wishlist!</p>
                    <button class="btn btn-primary" onclick="navigate('home')"><i class="fas fa-shopping-bag"></i> Browse Products</button>
                </div>
            `;
        } else {
            html += '<div class="wishlist-grid">';
            items.forEach(w => {
                const p = w.product;
                const imgUrl = getProductImageUrl(p);
                html += `
                    <div class="product-card fade-in">
                        <div class="product-image" onclick="navigate('product', ${p.id})">
                            <img src="${imgUrl}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'">
                            ${getStockLabel(p.stock)}
                        </div>
                        <div class="product-info">
                            <div class="product-category">${escapeHtml(p.category?.name || '')}</div>
                            <div class="product-name">${escapeHtml(p.name)}</div>
                            <div class="product-price-row">
                                <span class="product-price">${formatPrice(p.price)}</span>
                            </div>
                            <div style="display:flex;gap:0.5rem;margin-top:1rem">
                                ${p.stock > 0 ? `<button class="btn btn-primary btn-sm" onclick="quickAddToCart(${p.id})"><i class="fas fa-shopping-cart"></i> Add to Cart</button>` : ''}
                                <button class="btn btn-outline btn-sm" onclick="removeWishlistItem(${p.id})"><i class="fas fa-trash"></i> Remove</button>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
        }
        html += '</div>';
        main.innerHTML = html;
    } catch (e) {
        main.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Failed to load wishlist</h3></div>`;
    }
    hideLoading();
}

async function removeWishlistItem(productId) {
    try {
        await api.removeFromWishlist(productId);
        showToast('Removed from wishlist', 'info');
        renderWishlistPage();
    } catch (e) {
        showToast(e.message, 'error');
    }
}

// ========== PROFILE PAGE ==========
async function renderProfilePage() {
    const main = document.getElementById('main-content');
    showLoading();

    try {
        const result = await api.getMe();
        const user = result.data;

        main.innerHTML = `
            <div class="profile-page fade-in">
                <div class="profile-header">
                    <div class="profile-avatar"><i class="fas fa-user"></i></div>
                    <div>
                        <h2 style="font-size:1.5rem;color:var(--text-white)">${escapeHtml(user.name)}</h2>
                        <p style="color:var(--text-muted)">${escapeHtml(user.email)}</p>
                        <span class="order-status status-${user.status === 'ACTIVE' ? 'DELIVERED' : 'CANCELLED'}">${user.status}</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <h3 style="margin-bottom:1.5rem;color:var(--text-white)"><i class="fas fa-edit" style="color:var(--primary-light)"></i> Edit Profile</h3>
                        <form onsubmit="handleProfileUpdate(event)">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" class="form-control" id="profile-name" value="${escapeHtml(user.name)}" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" value="${escapeHtml(user.email)}" disabled>
                            </div>
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="tel" class="form-control" id="profile-phone" value="${escapeHtml(user.phone || '')}">
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <textarea class="form-control" id="profile-address" rows="3">${escapeHtml(user.address || '')}</textarea>
                            </div>
                            <div class="form-group">
                                <label>New Password (leave blank to keep current)</label>
                                <input type="password" class="form-control" id="profile-password" placeholder="Enter new password" minlength="6">
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save"></i> Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        `;
    } catch (e) {
        main.innerHTML = `<div class="empty-state"><h3>Failed to load profile</h3></div>`;
    }
    hideLoading();
}

async function handleProfileUpdate(e) {
    e.preventDefault();
    try {
        await api.updateProfile({
            name: document.getElementById('profile-name').value,
            phone: document.getElementById('profile-phone').value,
            address: document.getElementById('profile-address').value,
            password: document.getElementById('profile-password').value || null
        });
        showToast('Profile updated successfully!', 'success');

        // Update stored user name
        const stored = JSON.parse(localStorage.getItem('shopnow_user'));
        if (stored) {
            stored.name = document.getElementById('profile-name').value;
            localStorage.setItem('shopnow_user', JSON.stringify(stored));
            updateNavBar();
        }
    } catch (e) {
        showToast(e.message, 'error');
    }
}
