# 🛍️ ShopNow E-Commerce Platform

A production-ready, full-stack e-commerce platform built with Java Spring Boot for small and medium retail businesses.

![Java](https://img.shields.io/badge/Java-17-orange)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2-green)
![License](https://img.shields.io/badge/License-MIT-blue)

## ✨ Features

### Customer Features
- 🔐 User registration & login with JWT authentication
- 🛍️ Browse products with grid view
- 🔍 Advanced search with autocomplete
- 🏷️ Filter by category, price range, sort options
- 📦 Product details with recommendations
- 🛒 Shopping cart with quantity management
- ❤️ Wishlist functionality
- 🎫 Apply coupon codes for discounts
- 💳 Checkout with multiple payment methods (COD, Card, UPI, Net Banking)
- 📋 Order history with status tracking
- ❌ Cancel orders (if not shipped)
- 👤 Profile management

### Admin Features
- 📊 Analytics dashboard (revenue, orders, customers)
- 📦 Product management (CRUD with image upload)
- 🏷️ Category management
- 📋 Order management with status updates
- 👥 User management (block/unblock)
- 🎫 Coupon/discount management
- 📉 Inventory management with low-stock alerts
- 📈 Daily/monthly revenue tracking

## 🧠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Java 17, Spring Boot 3.2 |
| Security | Spring Security, JWT, BCrypt |
| ORM | Hibernate / JPA |
| Database | H2 (dev) / MySQL (prod) |
| API Docs | Swagger / OpenAPI |
| Frontend | HTML5, CSS3, JavaScript (Vanilla) |
| PDF/CSV | iText 8, Apache Commons CSV |
| Build | Maven |

## 🚀 Quick Start

### Prerequisites
- Java 17+ installed
- Maven 3.8+ installed
- (Optional) MySQL 8.0+ for production

### Run with H2 (Default - No setup needed!)

```bash
# Clone and navigate to project
cd deepaktt

# Run the application
mvn spring-boot:run
```

The app will start on **http://localhost:8080**

### Run with MySQL

1. Create database:
```sql
CREATE DATABASE shopnow_db;
```

2. Update `src/main/resources/application.properties`:
   - Comment out H2 config
   - Uncomment MySQL config
   - Set your MySQL username/password

3. Run:
```bash
mvn spring-boot:run
```

## 🔑 Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@shopnow.com | admin123 |
| Customer | john@example.com | customer123 |

## 📡 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/profile` | Update profile |

### Products (Public)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products` | List products (paginated) |
| GET | `/api/products/{id}` | Get product details |
| GET | `/api/products/search?query=` | Search products |
| GET | `/api/products/filter` | Filter products |
| GET | `/api/products/suggestions?query=` | Autocomplete |
| GET | `/api/products/{id}/recommendations` | Related products |
| GET | `/api/products/category/{id}` | By category |

### Categories (Public)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/categories` | List categories |

### Cart (Authenticated)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/cart` | Get cart |
| POST | `/api/cart/add` | Add to cart |
| PUT | `/api/cart/update` | Update quantity |
| DELETE | `/api/cart/remove` | Remove item |
| DELETE | `/api/cart/clear` | Clear cart |

### Wishlist (Authenticated)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/wishlist` | Get wishlist |
| POST | `/api/wishlist/add` | Add to wishlist |
| DELETE | `/api/wishlist/remove` | Remove |
| GET | `/api/wishlist/check` | Check status |

### Orders (Authenticated)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/orders/checkout` | Place order |
| GET | `/api/orders` | My orders |
| GET | `/api/orders/{id}` | Order details |
| POST | `/api/orders/{id}/cancel` | Cancel order |
| POST | `/api/orders/validate-coupon` | Validate coupon |

### Admin (Admin Role)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Dashboard stats |
| POST | `/api/admin/products` | Create product |
| PUT | `/api/admin/products/{id}` | Update product |
| DELETE | `/api/admin/products/{id}` | Delete product |
| PUT | `/api/admin/products/{id}/stock` | Update stock |
| GET | `/api/admin/products/low-stock` | Low stock alert |
| POST/PUT/DELETE | `/api/admin/categories/*` | Category CRUD |
| GET | `/api/admin/orders` | All orders |
| PUT | `/api/admin/orders/{id}/status` | Update status |
| GET | `/api/admin/users` | All users |
| PUT | `/api/admin/users/{id}/toggle-status` | Block/Unblock |
| POST/PUT/DELETE | `/api/admin/coupons/*` | Coupon CRUD |

### API Documentation
Visit **http://localhost:8080/swagger-ui.html** for interactive API docs.

## 🗄️ Database Schema

```
Users ──┬── Orders ──── OrderItems ──── Products ──── Categories
        │       └──── Payments
        ├── Carts ──── CartItems ──── Products
        └── Wishlists ──── Products
                                      Coupons (standalone)
```

## 📁 Project Structure

```
src/main/java/com/shopnow/ecommerce/
├── EcommerceApplication.java
├── config/         (Security, JWT, Web, CORS)
├── controller/     (REST API Controllers)
├── dto/            (Request/Response DTOs)
├── exception/      (Global Exception Handling)
├── model/          (JPA Entities)
├── repository/     (Spring Data JPA Repos)
└── service/        (Business Logic)

src/main/resources/
├── static/         (Frontend: HTML, CSS, JS)
├── application.properties
└── data.sql        (Sample data)
```

## 🔒 Security Features
- BCrypt password hashing
- JWT token authentication
- Role-based authorization (Admin/Customer)
- Input validation (backend + frontend)
- SQL injection protection (JPA parameterized queries)
- XSS protection (HTML escaping)
- CORS configuration
- Global exception handling

## 📝 License
MIT License - Free for commercial use.
